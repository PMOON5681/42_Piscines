#include "ft_abs.h"
#include <stdio.h>
int	main(void)
{
	int	n = 42;
	
	printf("%d\n", ABS(n));
	return (0);
}
