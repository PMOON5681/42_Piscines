/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: schueaka <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/10 13:47:05 by schueaka          #+#    #+#             */
/*   Updated: 2024/06/10 13:47:08 by schueaka         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	*ft_range(int min, int max)
{
	int	range;
	int	i;
	int	*dest;
	int	*d;

	i = 0;
	if (min >= max)
		return (0);
	range = max - min;
	dest = malloc(range * sizeof(int));
	if (!dest)
		return (0);
	while (i < range)
	{
		dest[i] = min + i;
		i++;
	}
	return (dest);
}

#include <stdio.h>

int		main(void)
{
  int	min;
  int	max;
  int	*tab;
  int	i = 0;
  int	size;

  min = 0;
  max = 'a';
  size = max - min;
  tab = ft_range(min, max);
  while(i < size)
  {
    printf("%d, ", tab[i]);
    i++;
  }
}
