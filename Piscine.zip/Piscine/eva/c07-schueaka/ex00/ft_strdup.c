/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: schueaka <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/10 13:42:51 by schueaka          #+#    #+#             */
/*   Updated: 2024/06/10 22:18:22 by tjiranar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_str_length(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

char	*ft_strdup(char *src)
{
	int		i;
	char	*dest;

	i = 0;
	dest = (char *)malloc((ft_str_length(src) + 1) * sizeof(char));
	if (!dest)
		return (0);
	while (src[i])
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
	return (dest);
}

#include <stdio.h>
#include <string.h>
int		main(void)
{
  char	*str;
  char	*allocated;

  str = "Hello World with malloc()";
  printf("original  : base  : $%s$ @ %p\n", str, str);
  allocated = strdup(str);
  printf("copied    : alloc : $%s$ @ %p\n", allocated, allocated);
  allocated = ft_strdup(str);
  printf("ft_copied : alloc : $%s$ @ %p\n", allocated, allocated);
}
