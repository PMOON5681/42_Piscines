/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: schueaka <schueaka@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/10 14:07:33 by schueaka          #+#    #+#             */
/*   Updated: 2024/06/10 14:07:47 by schueaka         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_ultimate_range(int **range, int min, int max)
{
	int	i;
	int	j;
	int	*d;

	if (min >= max)
	{
		*range = 0;
		return (0);
	}
	j = max - min;
	d = malloc(j * sizeof(int));
	if (!d)
	{
		*range = 0;
		return (-1);
	}
	*range = d;
	i = 0;
	while (i < j)
	{
		d[i] = min + i;
		i++;
	}
	return (i);
}

#include <stdio.h>
int	main(void)
{
	int	min;
	int	max;
	int	*tab;
	int	size;
	int	i = 0;

	min = -1;
	max = 10;
	size = ft_ultimate_range(&tab, min, max);
	printf("%d\n",size);
	while(i < size)
	{
    printf("%d, ", tab[i]);
    i++;
  }
}
