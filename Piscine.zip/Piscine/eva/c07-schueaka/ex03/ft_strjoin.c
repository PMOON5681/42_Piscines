/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: schueaka <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/10 14:52:18 by schueaka          #+#    #+#             */
/*   Updated: 2024/06/10 14:54:37 by schueaka         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

char	*ft_strcpy(char *d, char *src)
{
	int	i;

	i = 0;
	while (src[i] != '\0')
	{
		d[i] = src[i];
		i++;
	}
	d[i] = '\0';
	return (d);
}

int	ft_compute(char **strs, int size, int length)
{
	int	len;
	int	i;

	len = 0;
	i = 0;
	while (i < size)
	{
		len += ft_strlen(strs[i]);
		if (i < (size - 1))
			len += length;
		i++;
	}
	return (len);
}

char	*ft_inloop(int size, char **strs, char *sep, char *temp)
{
	int		i;
	char	*d;

	i = 0;
	d = temp;
	while (i < size)
	{
		ft_strcpy(temp, strs[i]);
		temp += ft_strlen(strs[i]);
		if (i < (size - 1))
		{
			ft_strcpy(temp, sep);
			temp += ft_strlen(sep);
		}
		i++;
	}
	*temp = '\0';
	return (d);
}

char	*ft_strjoin(int size, char **strs, char *sep)
{
	int		len;
	int		i;
	char	*d;
	char	*temp;

	if (size == 0)
	{
		d = malloc(sizeof(char));
		*d = '\0';
		return (d);
	}
	len = ft_compute(strs, size, ft_strlen(sep));
	d = malloc((len + 1) * sizeof(char));
	temp = d;
	if (!temp)
		return (0);
	i = 0;
	d = ft_inloop(size, strs, sep, temp);
	return (d);
}

#include <stdio.h>
int	main(void)
{
  int		index;
  char	**strs;
  char	*separator;
  char	*result;
  int	size;

  size = 3;
  strs = (char **)malloc(3 * sizeof(char *));
  strs[0] = (char *)malloc(sizeof(char) * 5 + 1);
  strs[1] = (char *)malloc(sizeof(char) * 7 + 1);
  strs[2] = (char *)malloc(sizeof(char) * 14 + 1);
  strs[0] = "Hello";
  strs[1] = "friend,";
  strs[2] = "you are awesome";
  separator = " ";
  result = ft_strjoin(size, strs, separator);
  printf("%s\n", result);
  free(result);
}
