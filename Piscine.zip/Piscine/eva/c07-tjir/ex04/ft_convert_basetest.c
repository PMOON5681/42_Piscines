/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_convert_basetest.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tjiranar <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/13 19:23:12 by tjiranar          #+#    #+#             */
/*   Updated: 2024/06/13 19:30:27 by tjiranar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_convert_base(char *nbr, char *base_from, char *base_to)
{
	//1010 01 0123456789
	//nbr basefrom baseto can be non-printable ,dont need to catch non-print
	//"   +---+123abf" -> -1;
	//integer INTMAX -> INTMIN
	//return (0) if base wrong
	//	base no + - ,no same number, ' '
	//
}
