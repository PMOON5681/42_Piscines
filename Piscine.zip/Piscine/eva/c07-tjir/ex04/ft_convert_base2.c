/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_convert_base2.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tjiranar <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/12 15:54:39 by tjiranar          #+#    #+#             */
/*   Updated: 2024/06/13 19:36:44 by tjiranar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	to_base_ten(char *base, char *str);
int	check_base(char *base);
int	ft_strlen(char *str);

int	total_lenght(int nb, int lbase)
{
	int	i;

	i = 0;
	if (nb < 0)
	{
		nb *= -1;
		i++;
	}
	while (nb / lbase > 0)
	{
		nb /= lbase;
		i++;
	}
	return (i);
}

char	*to_base(int nbr, char *base, int size)
{
	int		lbase;
	char	*number;
	int		i;

	i = 0;
	lbase = ft_strlen(base);
	number = malloc(sizeof(char) * (size));
	if (nbr < 0)
	{
		number[0] = '-';
		i = 1;
		nbr *= -1;
	}
	while (nbr >= lbase)
	{
		number[size] = base[nbr % lbase];
		nbr /= lbase;
		size--;
	}
	number[i] = base[nbr % lbase];
	return (number);
}

char	*ft_convert_base(char *nbr, char *base_from, char *base_to)
{
	int		nb;
	int		size;
	char	*result;
	int		lbase;

	result = "";
	nb = to_base_ten(base_from, nbr);
	if (check_base(base_to) == 0)
		return (0);
	lbase = ft_strlen(base_to);
	size = total_lenght(nb, lbase);
	result = to_base(nb, base_to, size);
	return (result);
}

/*#include <stdio.h>

int	main(void)
{
	printf("%s", ft_convert_base("  ++--&01", "01", "01"));
}*/
