/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tjiranar <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/05 14:14:21 by tjiranar          #+#    #+#             */
/*   Updated: 2024/06/13 13:37:41 by tjiranar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_ultimate_range(int	**range, int min, int max)
{
	int	i;
	int	*n;

	if (min >= max)
	{
		*range = 0;
		return (0);
	}
	n = (int *)malloc(sizeof(int) * max - min);
	if (!range)
	{
		*range = 0;
		return (-1);
	}
	*range = n;
	i = -1;
	while (++i < max - min)
		n[i] = min + i;
	return (max - min);
}

/*#include <stdio.h>

int	main(void)
{
	int	i;
	int n;
	int	*p;

	i = -1;
	n = ft_ultimate_range(&p, 3, 9);
	printf("This is size of range : %d\n", n);
	while (++i < n)
		printf("This is value in the array : %d\n",p[i]);
	free(p);
	return (0);
}*/
