/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tjiranar <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/13 13:38:30 by tjiranar          #+#    #+#             */
/*   Updated: 2024/06/13 19:44:52 by tjiranar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

int	ft_maxsize(char *str, char *charset)
{
	int	max;
	int	nextmax;
	int	i;
	int	j;

	i = -1;
	max = 0;
	nextmax = 0;
	while (str[++i])
	{
		j = -1;
		while (charset[++j])
		{
			if (str[i] == charset[j])
			{
				if (nextmax > max)
				{
					max = nextmax;
					nextmax = 0;
				}
			}
		}
		nextmax++;
	}
	return (max);
}

int	is_space(char c, char *charset)
{
	int	i;

	i = 0;
	while (charset[i])
	{
		if (charset[i] == c)
			return (1);
		i++;
	}
	return (0);
}

char	**ft_to_split(char *str, char *charset, char **strs)
{
	int	i;
	int	set;
	int	w;

	i = -1;
	w = 0;
	set = 0;
	while (str[++i])
	{
		if (!is_space(str[i], charset))
			strs[set][w++] = str[i];
		else
		{
			strs[set][w] = '\0';
			if (!is_space(str[i + 1], charset))
			{
				w = 0;
				set++;
			}
		}
	}
	strs[set++][w] = '\0';
	strs[set] = 0;
	return (strs);
}

char	**ft_split(char *str, char *charset)
{
	int		i;
	int		j;
	char	**strs;

	i = -1;
	j = ft_maxsize(str, charset);
	if (ft_strlen(charset) == 0)
		return (0);
	strs = malloc((j + 1) * sizeof(char *));
	if (!strs)
		return (0);
	while (++i < j)
		strs[i] = malloc(j * sizeof(char));
	strs = ft_to_split(str, charset, strs);
	return (strs);
}

//char **str[set][w] = {"The", "      ", "      "}

#include <stdio.h>

int	main(void)
{
	char	**strs;
	int		i;

	strs = ft_split("The CNSA Chang'e 6 completes sampling and takeoff from the far side of the Moon.", " ");
	i = 0;
	while (strs[i])
	{
		printf("str %d : %s\n", i + 1, strs[i]);
		i++;
	}
}
