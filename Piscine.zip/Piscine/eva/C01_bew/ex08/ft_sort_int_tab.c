/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: phkimpha <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/27 16:08:10 by phkimpha          #+#    #+#             */
/*   Updated: 2024/05/29 15:57:41 by tjiranar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_sort_int_tab(int *tab, int size)
{
	int	n;
	int	temp;

	n = 0;
	while (n < size - 1)
	{
		if (tab[n] > tab[n + 1])
		{
			temp = tab[n];
			tab[n] = tab[n + 1];
			tab[n + 1] = temp;
			n = 0;
		}
		else
		{
			n++;
		}
	}
}

#include <stdio.h>

int main(void)
{
	int tab[6] = {2, 1, 7, 5, 9, 3};
	int size = 6;

	ft_sort_int_tab(tab, size);
	printf("%d, %d, %d, %d, %d, %d", tab[0], tab[1], 
	tab[2], tab[3], tab[4], tab[5]); 
	return (0);
}	
