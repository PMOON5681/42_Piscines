/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nurairat <nurairat@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/12 12:21:13 by nurairat          #+#    #+#             */
/*   Updated: 2024/06/14 18:05:52 by nurairat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

int	str_len(char *s)
{
	int	i;

	i = 0;
	while (s[i])
	{
		i++;
	}
	return (i);
}

void	ft_putnbr_base(int nbr, char *base)
{
	unsigned int	nb;
	unsigned int	b;

	b = str_len(base);
	if (nbr < 0)
	{
		ft_putchar('-');
		nbr *= -1;
	}
	nb = nbr;
	if (nb / b > 0)
	{
		ft_putnbr_base(nb / b, base);
		ft_putnbr_base(nb % b, base);
	}
	else
		ft_putchar(base[nbr % b]);
}

// int main(void)
// {
// 	ft_putnbr_base(-2147483648, "0123456789");
// 	ft_putchar('\n');
// 	ft_putnbr_base(-2147483648, "01");
// 	ft_putchar('\n');
// 	ft_putnbr_base(9, "01");
// 	ft_putchar('\n');
// }
