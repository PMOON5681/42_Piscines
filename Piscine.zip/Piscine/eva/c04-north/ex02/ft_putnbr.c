/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nurairat <nurairat@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/12 12:20:41 by nurairat          #+#    #+#             */
/*   Updated: 2024/06/14 18:05:44 by nurairat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_putnbr(int nb)
{
	if (nb == -2147483648)
	{
		write(1, "-", 1);
		write(1, "2", 1);
		nb = 147483648;
	}
	if (nb < 0)
	{
		ft_putchar('-');
		nb = -nb;
	}
	if (nb > 9)
	{
		ft_putnbr(nb / 10);
	}
	ft_putchar(nb % 10 + '0');
}

#include <stdio.h>
int main(void)
{
    printf("This should be -2147483648\n");
    ft_putnbr(-2147483648);
    printf("\nThis should be -265\n");
    ft_putnbr(-269);
    printf("\nThis should be 75894\n");
    ft_putnbr(75894);
    printf("\nThis should be 2147483647\n");
    ft_putnbr(2147483647);
    printf("\nThis should be 10\n");
    ft_putnbr(10);
    printf("\nThis should be 9\n");
    ft_putnbr(9);
}
