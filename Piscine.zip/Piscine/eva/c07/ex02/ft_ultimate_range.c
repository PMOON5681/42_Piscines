/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rkhongcl <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/03 15:00:28 by rkhongcl          #+#    #+#             */
/*   Updated: 2024/06/03 15:00:37 by rkhongcl         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_ultimate_range(int **range, int min, int max)
{
	int	i;
	int	*sub;

	if (min >= max)
	{
		*range = NULL;
		return (0);
	}
	sub = (int *)malloc(sizeof(int) * (max - min));
	if (sub == NULL)
		return (-1);
	else
	{
		i = 0;
		while (i < max - min)
		{
			sub[i] = min + i;
			i++;
		}
		*range = sub;
		return (i);
	}
}

#include <stdio.h>
int main(void)
{
	int *a;

	int A = ft_ultimate_range(&a,3,5);
	for (int i = 0; i < 2; i++)
	{
		printf("%d ",a[i]);
	}
	printf("\n range : %d",A);
}
