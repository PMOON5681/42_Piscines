/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rkhongcl <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/03 14:41:21 by rkhongcl          #+#    #+#             */
/*   Updated: 2024/06/03 14:41:23 by rkhongcl         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

// int	ft_strlen(char *str)
// {
// 	int	i;

// 	i = 0;
// 	while (str[i] != '\0')
// 	{
// 		i++;
// 	}
// 	return (i);
// }

int	make_str(int size, char **strs, char *sep)
{
	int	i;
	int	j;
	int	k;

	i = 0;
	k = 0;
	while (strs[i] != NULL && i < size)
	{
		j = 0;
		while (strs[i][j] != '\0')
		{
			k++;
			j++;
		}
		j = 0;
		while (sep[j] != '\0' && i < size - 1)
		{
			k++;
			j++;
		}
		i++;
	}
	return (k);
}

char	*ft_strjoin(int size, char **strs, char *sep)
{
	int		i;
	int		j;
	int		count;
	char	*sub;

	i = 0;
	count = 0;
	if (size == 0)
		return ("");
	sub = (char *)malloc(make_str(size, strs, sep) * sizeof(char));
	while (strs[i] != NULL && i < size)
	{
		j = 0;
		while (strs[i][j] != '\0')
			sub[count++] = strs[i][j++];
		j = 0;
		while (sep[j] != '\0' && i < size -1)
			sub[count++] = sep[j++];
		i++;
	}
	sub[count] = '\0';
	return (sub);
}

#include <stdio.h>
int main()
{
	char *arr[] = {"hello","World","Myname_is_k*y"};
	char *haiyee = ft_strjoin(3,arr,"/");
	printf("%s",haiyee);
	free(haiyee);
}
