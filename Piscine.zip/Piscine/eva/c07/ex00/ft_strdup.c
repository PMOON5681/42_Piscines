/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rkhongcl <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/03 12:31:21 by rkhongcl          #+#    #+#             */
/*   Updated: 2024/06/03 12:31:22 by rkhongcl         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

char	*ft_strdup(char *src)
{
	int		i;
	char	*ptr;

	i = 0;
	while (src[i] != '\0')
		i++;
	if (!(i))
		return (NULL);
	ptr = (char *)malloc(i * sizeof(char));
	i = 0;
	while (src[i] != '\0')
	{
		ptr[i] = src[i];
		i++;
	}
	ptr[i] = '\0';
	return (ptr);
}

#include <stdio.h>
int main()
{
    char a[] = "hello World";
    char *BB = ft_strdup(a);
	printf("%p\n", a);
	printf("%p\n", BB);
    printf("%s\n", BB);
}