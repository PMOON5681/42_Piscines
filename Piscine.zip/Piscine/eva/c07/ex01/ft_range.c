/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rkhongcl <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/03 13:14:32 by rkhongcl          #+#    #+#             */
/*   Updated: 2024/06/03 13:14:36 by rkhongcl         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	*ft_range(int min, int max)
{
	int	i;
	int	*sub;

	i = 0;
	if (min == max)
		return (NULL);
	sub = (int *)malloc(sizeof(int) * (max - min));
	while (min < max)
	{
		sub[i] = min;
		min++;
		i++;
	}
	return (sub);
}

#include <stdio.h>
int	main()
{
	int	i;

	i = 0;
	int *a = ft_range(7,7);
	while(a[i] != '\0')
	{
		printf("%d,",a[i]);
		i++;
	}
	free(a);
}