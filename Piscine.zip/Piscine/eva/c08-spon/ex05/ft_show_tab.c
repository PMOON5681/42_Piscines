/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_show_tab.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: spornser <spornser@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/13 22:32:12 by spornser          #+#    #+#             */
/*   Updated: 2024/06/14 19:42:06 by tjiranar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../ex04/ft_stock_str.h"
//#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

/*
int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		i++;
	}
	return (i);
}

char	*ft_strdup(char *src)
{
	int		i;
	char	*c;

	i = 0;
	ft_strlen(src);
	c = malloc(sizeof(char) * ft_strlen(src)+1);
	if (c == NULL)
		return (NULL);
	while (src[i] != '\0')
	{
		c[i] = src[i];
		i++;
	}
	c[i] = '\0';
	return (c);
}
struct s_stock_str	*ft_strs_to_tab(int ac, char **av)
{
	int	i;

	t_stock_str *stock;

	stock = malloc(sizeof(t_stock_str) * (ac + 1));
	if (stock == NULL)
		return (NULL);
	while (i < ac)
	{
		stock[i].str = av[i];
		stock[i].copy = ft_strdup(av[i]);
		stock[i].size = ft_strlen(av[i]);
		i++;
	}
	stock[i].str = 0;
	stock[i].copy = 0;
	stock[i].size = 0;
	return (stock);
}
*/

int	fix_value(int nb)
{
	write(1, "-", 1);
	write(1, "2", 1);
	nb = 147483648;
	return (nb);
}

void	ft_putnbr(int nb)
{
	int	i[2];
	int	a[12];

	i[0] = 0;
	if (nb == -2147483648)
		nb = fix_value(nb);
	if (nb == 0)
		write(1, "0", 1);
	if (nb < 0)
	{
		write(1, "-", 1);
		nb = -nb;
	}
	while (nb)
	{
		i[1] = nb % 10;
		a[i[0]] = i[1];
		nb = nb / 10;
		i[0]++;
	}
	while (i[0]--)
	{
		a[i[0]] = a[i[0]] + '0';
		write(1, &a[i[0]], 1);
	}
}

void	ft_putstr(char *str)
{
	while (*str != 0)
	{
		write(1, str, 1);
		str++;
	}
}

void	ft_show_tab(struct s_stock_str *par)
{
	int	i;

	i = 0;
	while (par[i].str != 0)
	{
		ft_putstr(par[i].str);
		write(1, "\n", 1);
		ft_putnbr(par[i].size);
		write(1, "\n", 1);
		ft_putstr(par[i].copy);
		write(1, "\n", 1);
		i++;
	}
}

int	main(int ac, char **av)
{
	struct s_stock_str	*stock;

	stock = ft_strs_to_tab(ac - 1, av + 1);
	if (stock)
	{
		ft_show_tab(stock);
		for (int i = 0; i < ac - 1; i++)
			free(stock[i].copy);
		free(stock);
	}
	return (0);
}
