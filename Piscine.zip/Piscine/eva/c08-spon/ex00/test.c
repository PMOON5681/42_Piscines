#include "ft.h"

int	main()
{
	ft_putstr("hello");
}
