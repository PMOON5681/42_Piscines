/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi_base.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tjiranar <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/11 16:17:09 by tjiranar          #+#    #+#             */
/*   Updated: 2024/06/11 21:51:49 by tjiranar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

int	check_base(char *base)
{
	int	l;
	int	i;
	int	j;

	i = 0;
	l = ft_strlen(base);
	if (base[i] == '\0' || l == 1)
		return (0);
	while (base[i] != '\0')
	{
		if (base[i] <= 32 || base[i] == 127 || base[i] == '-' || base[i] == '+')
			return (0);
		j = i + 1;
		while (base[j] != '\0')
		{
			if (base[i] == base[j])
				return (0);
			j++;
		}
		i++;
	}
	return (i);
}

int	ft_frombase(char str, char *base)
{
	int	i;

	i = 0;
	while (base[i])
	{
		if (base[i] == str)
			return (i);
		i++;
	}
	return (-1);
}

int	ft_atoi(char *str, char *base, int lbase)
{
	int	i;
	int	j;
	int	sign;
	int	nb;

	i = 0;
	sign = 1;
	nb = 0;
	while (str[i] == ' ' || (str[i] >= 9 && str[i] <= 13))
		i++;
	while (str[i] == '-' || str[i] == '+')
	{
		if (str[i++] == '-')
			sign = sign * -1;
	}
	while (str[i])
	{
		j = ft_frombase(str[i], base);
		if (j >= 0)
			nb = (nb * lbase) + j;
		else
			return (nb * sign);
		i++;
	}
	return (nb * sign);
}

int	ft_atoi_base(char *str, char *base)
{
	int	lbase;
	int	nb;

	lbase = check_base(base);
	if (!lbase)
		return (0);
	nb = ft_atoi(str, base, lbase);
	return (nb);
}

/*#include <stdio.h>

int	main(void)
{
	printf("%d\n", ft_atoi_base("   +-+-mylit","mylitTLepInoY123"));
}*/
