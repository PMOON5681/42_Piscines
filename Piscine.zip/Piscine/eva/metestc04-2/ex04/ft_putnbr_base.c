/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tjiranar <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/29 13:27:52 by tjiranar          #+#    #+#             */
/*   Updated: 2024/05/31 16:52:36 by tjiranar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

int	check_base(char *base)
{
	int		l;
	int		i;
	int		j;

	i = 0;
	l = ft_strlen(base);
	if (base[i] == '\0' || l == 1)
		return (0);
	while (base[i] != '\0')
	{
		if (base[i] <= 32 || base[i] == 127 || base[i] == '-' || base[i] == '+')
			return (0);
		j = i + 1;
		while (base[j] != '\0')
		{
			if (base[i] == base[j])
				return (0);
			j++;
		}
		i++;
	}
	return (1);
}

void	to_base(int c, char *base, int l)
{
	unsigned int	nb;

	if (c < 0)
	{
		ft_putchar('-');
		c *= -1;
	}
	nb = (unsigned int)c;
	if (nb / l > 0)
	{
		to_base(nb / l, base, l);
		ft_putchar(base[nb % l]);
	}
	else
		ft_putchar(base[nb % l]);
}

void	ft_putnbr_base(int nbr, char *base)
{
	int	flag;
	int	lbase;

	lbase = ft_strlen(base);
	flag = check_base(base);
	if (flag)
		to_base(nbr, base, lbase);
}

/*#include <stdio.h>

int	main(void)
{
	ft_putnbr_base(-2147483648, "0123456789");
	return (0);
}*/
