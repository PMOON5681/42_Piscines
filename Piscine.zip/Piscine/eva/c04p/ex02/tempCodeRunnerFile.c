0);
		ft_putchar(nbr % 