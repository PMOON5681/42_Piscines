/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thacharo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/11 19:02:56 by thacharo          #+#    #+#             */
/*   Updated: 2024/06/11 23:31:52 by nkhuankh         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

void	parse_first_line(t_map *map, char *path)
{
	int		fd;
	char	buffer[1];

	fd = open_file(path);
	while (read(fd, buffer, 1) && buffer[0] != '\n' && buffer[0] != '.')
		;
	map -> empty_char = buffer[0];
	read(fd, buffer, 1);
	map -> obstacle_char = buffer[0];
	read(fd, buffer, 1);
	map -> mark_char = buffer[0];
	close(fd);
}
