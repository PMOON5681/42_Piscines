/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   str_grid.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thacharo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/12 15:50:36 by thacharo          #+#    #+#             */
/*   Updated: 2024/06/12 17:23:47 by nkhuankh         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

void	grid_cols(t_map *map, char *str)
{
	int	name;
	int	i;

	i = 0;
	name = 0;
	map -> cols = 0;
	while (str[i])
	{
		if (str[i] == '\n' && name == 0)
			name++;
		else if (str[i] == '\n')
			return ;
		else if (name == 1)
			map -> cols++;
		i++;
	}
}

void	grid_rows(t_map *map, char *str)
{
	int	name;
	int	i;

	i = 0;
	name = 0;
	map -> rows = 0;
	while (str[i])
	{
		if (str[i] == '\n' && name == 0)
			name++;
		else if (str[i] == '\n')
			map -> rows++;
		i++;
	}
}

void	grid_read_map(t_map *map, char *str)
{
	int	i;
	int	j;
	int	count;

	i = -1;
	count = 0;
	while (str[count] != '\n')
		count++;
	while (++i < map -> rows)
	{
		j = 0;
		while (j < map -> cols)
		{
			if (str[++count] != '\n')
			{
				map -> grid[i][j] = str[count];
				j++;
			}
		}
	}
}

void	grid_str(t_map *map, char *str)
{
	char	*head;
	int		count;
	int		i;

	count = 0;
	i = -1;
	while (str[++i] != '\n')
		count++;
	head = (char *)malloc(sizeof(char) * (count + 1));
	i = -1;
	while (str[++i] != '\n')
		head[i] = str[i];
	validate_header(head, map);
	free(head);
	grid_cols(map, str);
	grid_rows(map, str);
	allocate_grid(map);
	grid_read_map(map, str);
}
