/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   malloc.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thacharo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/11 00:24:47 by thacharo          #+#    #+#             */
/*   Updated: 2024/06/11 23:33:55 by nkhuankh         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

// Function to allocate memory for the grid
void	allocate_grid(t_map *map)
{
	int	i;

	map -> grid = (char **)malloc((map -> rows) * sizeof(char *));
	if (map -> grid == NULL)
	{
		exit(0);
	}
	i = 0;
	while (i < map -> rows)
	{
		map -> grid[i] = (char *)malloc((map -> cols) * sizeof(char));
		i++;
	}
}
