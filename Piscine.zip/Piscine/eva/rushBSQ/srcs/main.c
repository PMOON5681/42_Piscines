/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thacharo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/10 17:30:47 by thacharo          #+#    #+#             */
/*   Updated: 2024/06/12 17:37:42 by nkhuankh         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

void	blank(t_map *map)
{
	map->map1d = read_input();
	grid_str(map, map->map1d);
	find_bsq(map);
	print_grid(map);
	free_grid(map->grid, map->rows);
	free(map->map1d);
}

int	main(int argc, char **argv)
{
	t_map	map;
	int		i;

	if (argc == 1)
		blank(&map);
	else
	{
		i = -1;
		while (++i < argc)
		{
			if (create_map(&map, argv[i]))
			{
				find_bsq(&map);
				print_grid(&map);
				free_grid(map.grid, map.rows);
				if (argc > 2)
					write(1, "\n", 1);
			}
		}
	}
	return (0);
}
