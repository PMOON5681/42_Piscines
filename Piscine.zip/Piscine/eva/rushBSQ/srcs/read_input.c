/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   read_input.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thacharo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/12 13:52:09 by thacharo          #+#    #+#             */
/*   Updated: 2024/06/12 15:47:43 by thacharo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

char	*ft_strcat(char *dest, char *src)
{
	int	i;
	int	dest_len;

	i = 0;
	dest_len = ft_strlen(dest);
	while (src[i] != '\0')
	{
		dest[dest_len + i] = src[i];
		i++;
	}
	dest[dest_len + i] = '\0';
	return (dest);
}

char	*read_input(void)
{
	char	buffer[1];
	char	*str;
	int		i;

	i = 0;
	str = (char *)malloc(sizeof(char) * 4096);
	str[0] = '\0';
	while ((read(STDIN_FILENO, buffer, 1)))
	{
		str[i] = buffer[0];
		i++;
	}
	return (str);
}
