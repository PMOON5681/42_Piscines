/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   dp_algo.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nkhuankh <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/11 01:42:00 by nkhuankh          #+#    #+#             */
/*   Updated: 2024/06/11 18:05:37 by thacharo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

// Function to initialize the DP table
int	**dp_table(t_map *map)
{
	int	**dp;
	int	i;

	dp = (int **)malloc(map->rows * sizeof(int *));
	if (!dp)
		return (NULL);
	i = 0;
	while (i < map->rows)
	{
		dp[i] = (int *)malloc(map->cols * sizeof(int));
		i++;
	}
	return (dp);
}

// Function to fill the DP table
void	fill_dp_table(t_map *map, int **dp)
{
	map->i = -1;
	while (++map->i < map->rows)
	{
		map->j = -1;
		while (++map->j < map->cols)
		{
			if (map->grid[map->i][map->j] == map->empty_char)
			{
				if (map->i == 0 || map->j == 0)
					dp[map->i][map->j] = 1;
				else
				{
					map->min_val = dp[map->i - 1][map->j];
					if (dp[map->i][map->j - 1] < map->min_val)
						map->min_val = dp[map->i][map->j - 1];
					if (dp[map->i - 1][map->j - 1] < map->min_val)
						map->min_val = dp[map->i - 1][map->j - 1];
					dp[map->i][map->j] = map->min_val + 1;
				}
			}
			else
				dp[map->i][map->j] = 0;
		}
	}
}

// Function to find the largest square in the DP table
int	find_max_square(t_map *map, int **dp, int *max_i, int *max_j)
{
	int		i;
	int		j;
	int		max_size;

	i = 0;
	max_size = 0;
	*max_i = 0;
	*max_j = 0;
	while (i < map->rows)
	{
		j = 0;
		while (j < map->cols)
		{
			if (dp[i][j] > max_size)
			{
				max_size = dp[i][j];
				*max_i = i;
				*max_j = j;
			}
			j++;
		}
		i++;
	}
	return (max_size);
}

// Function to mark the largest square in the grid
void	mark_bsq(t_map *map, int max_size, int max_i, int max_j)
{
	int	i;
	int	j;

	i = max_i - max_size + 1;
	while (i <= max_i)
	{
		j = max_j - max_size + 1;
		while (j <= max_j)
		{
			map->grid[i][j] = map->mark_char;
			j++;
		}
		i++;
	}
}

// Function to find the largest square using dynamic programming
void	find_bsq(t_map *map)
{
	int	**dp;
	int	max_size;
	int	max_i;
	int	max_j;
	int	i;

	dp = dp_table(map);
	fill_dp_table(map, dp);
	max_size = find_max_square(map, dp, &max_i, &max_j);
	mark_bsq(map, max_size, max_i, max_j);
	i = 0;
	while (i < map->rows)
	{
		free(dp[i]);
		i++;
	}
	free(dp);
}
