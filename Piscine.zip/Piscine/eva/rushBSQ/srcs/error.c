/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   error.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nkhuankh <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/12 15:18:51 by nkhuankh          #+#    #+#             */
/*   Updated: 2024/06/12 15:32:21 by nkhuankh         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

int	validate_header(char *header, t_map *map)
{
	if (ft_strlen(header) < 4)
	{
		write(1, "map error\n", 10);
		return (0);
	}
	map->empty_char = header[ft_strlen(header) - 3];
	map->obstacle_char = header[ft_strlen(header) - 2];
	map->mark_char = header[ft_strlen(header) - 1];
	if (map->empty_char == map->obstacle_char
		|| map->empty_char == map->mark_char
		|| map->obstacle_char == map->mark_char)
	{
		write(1, "map error\n", 10);
		return (0);
	}
	header[ft_strlen(header) - 3] = '\0';
	map->head_rows = ft_atoi(header);
	if (map->head_rows <= 0)
	{
		write(1, "map error\n", 10);
		return (0);
	}
	return (1);
}

int	read_header(int fd, t_map *map)
{
	char	buffer[1024];
	int		n;
	char	*newline;

	n = read(fd, buffer, sizeof(buffer) - 1);
	if (n <= 0)
	{
		write(1, "map error\n", 10);
		return (0);
	}
	buffer[n] = '\0';
	newline = ft_strstr(buffer, "\n");
	if (!newline)
	{
		write(1, "map error\n", 10);
		return (0);
	}
	*newline = '\0';
	return (validate_header(buffer, map));
}
