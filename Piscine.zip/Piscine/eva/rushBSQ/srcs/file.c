/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   file.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thacharo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/10 19:34:03 by thacharo          #+#    #+#             */
/*   Updated: 2024/06/12 15:18:05 by nkhuankh         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

/* Get map rows by reading with neglecting map name */
void	ft_map_cols(t_map *map, char *path)
{
	int		fd;
	int		name;
	char	buffer[1];

	map -> cols = 0;
	name = 0;
	fd = open_file(path);
	while (read(fd, buffer, 1))
	{
		if (buffer[0] == '\n' && name == 0)
			name++;
		else if (buffer[0] == '\n')
		{
			close(fd);
			return ;
		}
		else if (name == 1)
			map -> cols++;
	}
}

/* Get map columns by reading with neglecting map name */
void	ft_map_rows(t_map *map, char *path)
{
	int		fd;
	int		name;
	char	buffer[1];

	map -> rows = 0;
	name = 0;
	fd = open_file(path);
	while (read(fd, buffer, 1))
	{
		if (buffer[0] == '\n' && name == 0)
			name++;
		else if (buffer[0] == '\n')
			map -> rows++;
	}
	close(fd);
}

int	open_file(char *path)
{
	int	fd;

	fd = open(path, O_RDONLY);
	if (fd == -1)
	{
		write(1, "map error\n", 10);
		exit(0);
	}
	return (fd);
}

void	ft_read_map(t_map *map, char *path)
{
	int		i;
	int		j;
	int		fd;
	char	buffer[1];

	fd = open_file(path);
	while (read(fd, buffer, 1) && buffer[0] != '\n')
		;
	i = -1;
	while (++i < map -> rows)
	{
		j = 0;
		while (j < map -> cols)
		{
			read(fd, buffer, sizeof(buffer));
			if (buffer[0] != '\n')
			{
				map -> grid[i][j] = buffer[0];
				j++;
			}
		}
	}
	close(fd);
}

int	create_map(t_map *map, char *path)
{
	int		fd;

	fd = open_file(path);
	if (!read_header(fd, map))
	{
		close(fd);
		exit(1);
	}
	else
	{
		ft_map_rows(map, path);
		ft_map_cols(map, path);
		allocate_grid(map);
		ft_read_map(map, path);
	}
	return (1);
}
