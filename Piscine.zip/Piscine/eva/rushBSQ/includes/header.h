/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   header.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thacharo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/10 17:53:19 by thacharo          #+#    #+#             */
/*   Updated: 2024/06/12 17:29:22 by nkhuankh         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HEADER_H
# define HEADER_H

# include <unistd.h>
# include <fcntl.h>
# include <stdlib.h>
# include <stdio.h>

typedef struct s_map
{
	int		rows;
	int		cols;
	int		i;
	int		j;
	int		min_val;
	char	empty_char;
	char	obstacle_char;
	char	mark_char;
	char	**grid;
	int		head_rows;
	char	*map1d;
}	t_map;

int		ft_file_len(char *str);
void	ft_map_rows(t_map *map, char *path);
void	ft_map_cols(t_map *map, char *path);
int		open_file(char *path);
void	allocate_grid(t_map *map);
void	ft_read_map(t_map *map, char *path);
char	*read_file(char *path, int len);
void	print_grid(t_map *map);
int		**dp_table(t_map *map);
void	fill_dp_table(t_map *map, int **dp);
int		find_max_square(t_map *map, int **dp, int *max_i, int *max_j);
int		create_map(t_map *map, char *path);
void	mark_bsq(t_map *map, int max_size, int max_i, int max_j);
void	find_bsq(t_map *map);
void	free_grid(char **arr, int rows);
void	parse_first_line(t_map *map, char *path);
void	ft_putstr(char *s, int fd);
int		ft_strlen(char *s);
char	*ft_strstr(char *str, char *to_find);
int		ft_atoi(char *str);
int		validate_header(char *header, t_map *map);
int		read_header(int fd, t_map *map);
void	grid_cols(t_map *map, char *str);
void	grid_rows(t_map *map, char *str);
void	grid_read_map(t_map *map, char *str);
void	grid_str(t_map *map, char *str);
char	*ft_strcat(char *dest, char *src);
char	*read_input(void);

#endif
