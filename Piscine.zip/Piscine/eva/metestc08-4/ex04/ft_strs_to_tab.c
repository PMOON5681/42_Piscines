/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strs_to_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tjiranar <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/10 13:15:42 by tjiranar          #+#    #+#             */
/*   Updated: 2024/06/10 18:42:42 by tjiranar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_stock_str.h"
#include <stdlib.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

char	*ft_strdup(char *str)
{
	int		i;
	char	*w;

	i = -1;
	w = (char *)malloc(ft_strlen(str) * sizeof(char) + 1);
	if (!w)
		return (0);
	while (str[++i])
		w[i] = str[i];
	w[i] = '\0';
	return (w);
}

struct s_stock_str	*ft_strs_to_tab(int ac, char **av)
{
	int					i;
	struct s_stock_str	*st_arr;
	struct s_stock_str	*ptr;

	ptr = malloc((ac + 1) * sizeof(struct s_stock_str));
	st_arr = ptr;
	if (!st_arr)
		return (NULL);
	i = -1;
	while (++i < ac)
	{
		st_arr[i].size = ft_strlen(av[i]);
		st_arr[i].str = av[i];
		st_arr[i].copy = ft_strdup(av[i]);
	}
	st_arr[i].str = 0;
	st_arr[i].copy = 0;
	return (st_arr);
}

/*#include <stdio.h>

int	main(int ac, char **av)
{
	int	i;
	struct s_stock_str	*st_arr;

	i = -1;
	st_arr = ft_strs_to_tab(ac, av);
	while (++i < ac)
		printf("%d : %s : %s \n", st_arr[i].size, st_arr[i].str, st_arr[i].copy);
	i = -1;
	while (++i < ac)
		free (st_arr[i].copy);
	free (st_arr);
}*/
