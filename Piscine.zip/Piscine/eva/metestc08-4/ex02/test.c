#include <stdio.h>
#include "ft_abs.h"

int	main(void)
{
	printf("%d\n", ABS(42));
}
