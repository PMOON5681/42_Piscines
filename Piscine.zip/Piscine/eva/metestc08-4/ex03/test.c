#include <stdio.h>
#include "ft_point.h"

void set_point(t_point *point)
{
	point->x = 4321;
	point->y = 1234;
}

int	main()
{
	t_point	point;
	set_point(&point);
	printf("x : %d y : %d", point.x, point.y);
}
