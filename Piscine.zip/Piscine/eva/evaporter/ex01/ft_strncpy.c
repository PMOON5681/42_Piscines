/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: daporter <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/27 15:46:56 by daporter          #+#    #+#             */
/*   Updated: 2024/05/30 18:48:30 by tjiranar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	unsigned int	i;

	i = 0;
	while ((src[i] != '\0') && (i < n))
	{
		dest[i] = src[i];
		i++;
	}
	while (i < n)
	{
		dest[i] = '\0';
		i++;
	}
	return (dest);
}

#include <stdio.h>
int	main(void)
{
	char source[] = "Source";
	char destination[10] = "";
	unsigned int	n;

	n = 3;

	printf("==Before *ft_strncpy==\n");
	printf("Source: %s\nDestination:%s\n", source, destination);

	ft_strncpy(destination, source, n);

	printf("==After *ft_strncpy==\n");
	printf("Source: %s\nDestination: %s\n", source, destination);

	return(0);
}
