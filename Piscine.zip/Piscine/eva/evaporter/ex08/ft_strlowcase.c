/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlowcase.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: daporter <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/28 17:00:43 by daporter          #+#    #+#             */
/*   Updated: 2024/05/30 15:07:45 by daporter         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

char	*ft_strlowcase(char *str)
{
	char	*temp;

	temp = str;
	while (*str != '\0')
	{
		if ((*str >= 'A') && (*str <= 'Z'))
		{
			*str = (*str + 32);
		}
		str++;
	}
	return (temp);
}

/*#include <stdio.h>

int	main(void)
{
	char srcstr[] = "Hello World";
	printf("Source string: %s\n", srcstr);

	char *newstr = ft_strlowcase(srcstr);
	printf("New string: %s\n", newstr);
}*/
