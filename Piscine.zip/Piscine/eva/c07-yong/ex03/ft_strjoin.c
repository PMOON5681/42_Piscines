/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wkullana <wkullana@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/05 17:03:33 by wkullana          #+#    #+#             */
/*   Updated: 2024/06/10 09:47:52 by wkullana         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

int	mstr(int size, char **strs, char *sep)
{
	int	count;
	int	len;

	count = 0;
	len = 0;
	while (count < size)
	{
		len += ft_strlen(strs[count]);
		if (count < size - 1)
			len += ft_strlen(sep);
		count++;
	}
	return (len + 1);
}

char	*ft_strjoin(int size, char **strs, char *sep)
{
	int		count;
	int		i;
	int		j;
	char	*strjoin;

	count = 0;
	i = 0;
	j = 0;
	strjoin = malloc((mstr(size, strs, sep)) * sizeof(char));
	if (!strjoin)
		return (NULL);
	while (count < size)
	{
		i = 0;
		while (strs[count][i])
			strjoin[j++] = strs[count][i++];
		i = 0;
		while (sep[i] && count < size - 1)
			strjoin[j++] = sep[i++];
		count++;
	}
	strjoin[j] = '\0';
	return (strjoin);
}

// #include <stdio.h>

// int	main(void)
// {
// 	char	*tab[4];
// 	tab[0] = "urmm";
// 	tab[1] = "what";
// 	tab[2] = "The";
// 	tab[3] = "urmm";
// 	printf("%s", ft_strjoin(2, tab, "___"));
// 	return (0);
// }