/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wkullana <wkullana@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/05 15:47:56 by wkullana          #+#    #+#             */
/*   Updated: 2024/06/10 09:47:49 by wkullana         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	*ft_range(int min, int max)
{
	int	i;
	int	*range;
	int	diff;

	i = 0;
	range = NULL;
	if (min >= max)
		return (NULL);
	diff = max - min;
	range = malloc(diff * sizeof(int));
	while (i < diff)
	{
		range[i] = min + i;
		i++;
	}
	return (range);
}
