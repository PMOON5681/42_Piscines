/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wkullana <wkullana@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/06 09:24:15 by wkullana          #+#    #+#             */
/*   Updated: 2024/06/10 16:08:46 by wkullana         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
		i++;
	return (i);
}

int	is_sep(char c, char *charset)
{
	int	i;

	i = 0;
	while (charset[i] != '\0')
	{
		if (c == charset[i])
			return (1);
		i++;
	}
	if (c == '\0')
		return (1);
	return (0);
}

int	lenstr(char *str, char *charset)
{
	int	i;
	int	words;

	words = 0;
	i = 0;
	while (str[i] != '\0')
	{
		if (is_sep(str[i], charset) && i > 0 && !is_sep(str[i - 1], charset))
			words++;
		i++;
	}
	if (i == 0)
		return (words);
	return (words + 2);
}

char	**ft_split(char *str, char *charset)
{
	char	**res;
	int		i;
	int		j;
	int		k;

	i = 0;
	res = malloc((lenstr(str, charset)) * sizeof(char *));
	while (i < lenstr(str, charset) - 1)
		res[i++] = malloc((ft_strlen(str) + 1) * sizeof(char));
	i = 0;
	k = 0;
	while (str[k] != '\0')
	{
		j = 0;
		while (!is_sep(str[k], charset) && str[k])
			res[i][j++] = str[k++];
		if (j != 0)
			res[i++][j] = '\0';
		k++;
	}
	res[i] = NULL;
	return (res);
}

// #include <stdio.h>

// int	main(void)
// {
// 	char	**arr;
// 	int		i;

// 	i = 0;
// 	// arr = ft_split("sadfas()asdf", " _,-");
// 	arr = ft_split("-You are,my_sunshine=my-only_sunshine ", " _,-");
// 	while (arr[i])
// 	{
// 		printf("%s\n", arr[i]);
// 		i++;
// 	}
// }
