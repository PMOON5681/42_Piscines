/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wkullana <wkullana@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/05 15:47:56 by wkullana          #+#    #+#             */
/*   Updated: 2024/06/10 16:08:48 by wkullana         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_ultimate_range(int **range, int min, int max)
{
	int	i;
	int	diff;
	int	*ptr;

	i = 0;
	if (min >= max)
	{
		*range = NULL;
		return (0);
	}
	diff = max - min;
	ptr = malloc(diff * sizeof(int));
	if (!ptr)
		return (-1);
	while (i < diff)
	{
		ptr[i] = min + i;
		i++;
	}
	*range = ptr;
	return (i);
}

// #include <stdio.h>
// int		main(void)
// {
// 	int i;
// 	int *tab;
// 	int min;
// 	int max;
// 	int size;

// 	min = -10;
// 	max = -2;
// 	size = ft_ultimate_range(&tab, min, max);
// 	if (tab != NULL)
// 	{
// 		i = -1;
// 		while (++i < max - min)
// 		{
// 			printf("%d\n", tab[i]);
// 		}
// 	}
// 	else
// 		printf("raburdddd ahh");
// }