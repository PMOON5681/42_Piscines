/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_convert_base2.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wkullana <wkullana@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/06 09:24:15 by wkullana          #+#    #+#             */
/*   Updated: 2024/06/10 16:09:55 by wkullana         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	get_index(char c, char *base)
{
	int	i;

	i = 0;
	while (base[i])
	{
		if (c == base[i])
			return (i);
		i++;
	}
	return (-1);
}

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
		i++;
	return (i);
}

int	space(char *str)
{
	int	i;

	i = 0;
	while (str[i] == ' ' || (9 <= str[i] && str[i] <= 13))
		i++;
	return (i);
}

int	checkbase(char *str)
{
	int	i;
	int	j;
	int	len;

	len = ft_strlen(str);
	if (len <= 1)
		return (0);
	i = 0;
	while (i < len)
	{
		j = i + 1;
		while (j < len)
		{
			if (str[i] == str[j])
				return (0);
			j++;
		}
		if (str[i] == '+' || str[i] == '-' || str[i] == ' '
			|| (9 <= str[i] && str[i] <= 13))
			return (0);
		i++;
	}
	return (len);
}

int	input_is_error(char *nbr, char *base_from)
{
	int	i;
	int	j;

	i = 0;
	while (nbr[i])
	{
		j = 0;
		while (base_from[j])
		{
			if (nbr[i] == base_from[j])
				break ;
			if (j == ft_strlen(base_from) - 1)
				return (1);
			j++;
		}
		i++;
	}
	return (0);
}
