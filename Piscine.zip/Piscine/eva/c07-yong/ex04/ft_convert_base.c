/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_convert_base.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: wkullana <wkullana@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/06 09:24:15 by wkullana          #+#    #+#             */
/*   Updated: 2024/06/10 16:10:22 by wkullana         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	get_index(char c, char *base);
int	ft_strlen(char *str);
int	space(char *s);
int	checkbase(char *b);
int	input_is_error(char *nbr, char *base_from);

int	ft_atoi_base(char *nbr, char *base_from, int base_sys)
{
	int	i;
	int	signs;
	int	num;

	i = space(nbr);
	signs = 1;
	num = 0;
	while (nbr[i] == '-' || nbr[i] == '+')
	{
		if (nbr[i] == '-')
			signs *= -1;
		i++;
	}
	while (get_index(nbr[i], base_from) >= 0)
	{
		num *= base_sys;
		num += get_index(nbr[i], base_from);
		i++;
	}
	return (num * signs);
}

char	*ft_putnbr_base(int num, char *base_to, int base_sys)
{
	int			i;
	long int	lnum;
	char		*conv_num;

	i = 32;
	lnum = num;
	conv_num = malloc(sizeof(char) * (1 + 32 + 1));
	if (!conv_num)
		return (NULL);
	if (lnum < 0)
		lnum *= -1;
	conv_num[i--] = '\0';
	while (lnum >= base_sys)
	{
		conv_num[i--] = base_to[lnum % base_sys];
		lnum /= base_sys;
	}
	conv_num[i] = base_to[lnum % base_sys];
	if (num < 0)
		conv_num[--i] = '-';
	return (&conv_num[i]);
}

char	*ft_convert_base(char *nbr, char *base_from, char *base_to)
{
	int		base_sysfrom;
	int		base_systo;
	int		num;
	char	*converted;

	base_sysfrom = checkbase(base_from);
	base_systo = checkbase(base_to);
	if (!(checkbase(base_from) && checkbase(base_to))
		|| input_is_error(nbr, base_from))
		return (NULL);
	num = ft_atoi_base(nbr, base_from, base_sysfrom);
	converted = ft_putnbr_base(num, base_to, base_systo);
	return (converted);
}

// #include <stdio.h>

// int main(int ac, char **av)
// {
// 	(void)ac;
// 	printf("%s", ft_convert_base(av[1], av[2], av[3]));
// }
