/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pibasri <pibasri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/25 22:16:23 by pibasri           #+#    #+#             */
/*   Updated: 2024/05/29 16:52:08 by tjiranar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_strlowcase(char *str)
{
	while (*str != '\0')
	{
		if (*str >= 65 && *str <= 90)
		{
			*str = *str + 32;
		}
		str++;
	}
}

char	*ft_strcapitalize(char *str)
{
	int	i;
	int	cap;

	i = 0;
	cap = 1;
	ft_strlowcase(str);
	while (str[i] != '\0')
	{
		if ((str[i] >= 'a' && str[i] <= 'z') && cap == 1)
		{
			if (str[i - 1] < 'a' || str[i - 1] > 'z')
			{
				if (str[i - 1] < '0' || str[i - 1] > '9')
				{
					str[i] -= 32;
					cap = 0;
				}
			}
		}
		else if (str[i] < 'a' || str[i] > 'z')
			cap = 1;
		i++;
	}
	return (str);
}

#include <stdio.h>
int main()
{
	char	w[100] = "salut, comment tu vas ? 42mots qUarante-deux; cinquante+et+un";
	ft_strcapitalize(w);
	printf("%s", w);
}
