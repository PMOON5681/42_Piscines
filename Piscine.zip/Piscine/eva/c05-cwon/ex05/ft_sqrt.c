/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sqrt.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cwon <cwon@student.42bangkok.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/31 14:04:51 by cwon              #+#    #+#             */
/*   Updated: 2024/06/11 22:31:27 by cwon             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// once again, logarithmic time via binary search
// averaging method takes care of integer overflow
int	ft_sqrt(int nb)
{
	int		left;
	int		right;
	long	middle;

	left = 0;
	right = nb + 1;
	if (nb < 0)
		return (0);
	while (right - left > 1)
	{
		middle = left + (right - left) / 2;
		if (middle * middle < nb)
			left = middle;
		else
			right = middle;
	}
	if (left * left == nb)
		return (left);
	else if (right * right == nb)
		return (right);
	return (0);
}

#include <stdio.h>
int main()
{
	for(int i = -2; i < 101; i++)
		printf("perfect square root of %d: %d\n", i, ft_sqrt(i));
	return 0;
} 