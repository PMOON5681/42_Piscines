/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cwon <cwon@student.42bangkok.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/30 20:43:10 by cwon              #+#    #+#             */
/*   Updated: 2024/06/11 22:20:32 by cwon             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// also log time!!!
int	power_helper(int nb, int power, int odd_powers)
{
	if (power < 0)
		return (0);
	else if (!power)
		return (odd_powers);
	else
	{
		if (power % 2)
			return (power_helper(nb * nb, (power - 1) / 2, nb * odd_powers));
		else
			return (power_helper(nb * nb, power / 2, odd_powers));
	}
}

int	ft_recursive_power(int nb, int power)
{
	return (power_helper(nb, power, 1));
}

#include <stdio.h>
int main()
{
	for(int i = -2; i < 10; i++)
	{
		printf("powers of %d\n", i);
		for(int j = -2; j < 10; j++)
			printf("exponent: %d, product: %d\n", j, ft_recursive_power(i, j));
		printf("\n");
	}
	return 0;
}