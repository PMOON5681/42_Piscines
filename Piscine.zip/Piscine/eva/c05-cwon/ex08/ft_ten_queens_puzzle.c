/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ten_queens_puzzle.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cwon <cwon@student.42bangkok.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/03 13:37:38 by cwon              #+#    #+#             */
/*   Updated: 2024/06/11 22:31:13 by cwon             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	possible(char grid[10][10], int col, int row)
{
	int	i;

	i = -1;
	while (++i < 10)
	{
		if (grid[i][col] == 'q')
			return (0);
		if (grid[row][i] == 'q')
			return (0);
		if (row + i < 10 && col + i < 10 && grid[row + i][col + i] == 'q')
			return (0);
		if (row + i < 10 && col - i >= 0 && grid[row + i][col - i] == 'q')
			return (0);
		if (row - i >= 0 && col + i < 10 && grid[row - i][col + i] == 'q')
			return (0);
		if (row - i >= 0 && col - i >= 0 && grid[row - i][col - i] == 'q')
			return (0);
	}
	return (1);
}

int	finished(char grid[10][10])
{
	char	arr[11];
	int		row;
	int		col;
	int		count;

	count = 0;
	arr[10] = '\n';
	col = -1;
	while (++col < 10)
	{
		row = -1;
		while (++row < 10)
		{
			if (grid[row][col] == 'q')
				arr[count++] = row + '0';
		}
	}
	if (count == 10)
	{
		write(1, arr, 11);
		return (1);
	}
	return (0);
}

void	solve(char grid[10][10], int col, int row, int *total)
{
	if (finished(grid))
	{
		(*total)++;
		if (col == 9 && row == 9)
			return ;
	}
	while (++col < 10)
	{
		row = -1;
		while (++row < 10)
		{
			if (grid[row][col] == '0' && possible(grid, col, row))
			{
				grid[row][col] = 'q';
				solve(grid, col, row, total);
				grid[row][col] = '0';
			}
		}
		return ;
	}
}

int	ft_ten_queens_puzzle(void)
{
	char	grid[10][10];
	int		total;
	int		col;
	int		row;

	row = -1;
	total = 0;
	while (++row < 10)
	{
		col = -1;
		while (++col < 10)
			grid[row][col] = '0';
	}
	solve(grid, -1, -1, &total);
	return (total);
}
#include <stdio.h>
int main()
{
	printf("%d\n",ft_ten_queens_puzzle());
	return 0;
}