/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_fibonacci.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cwon <cwon@student.42bangkok.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/30 20:58:22 by cwon              #+#    #+#             */
/*   Updated: 2024/06/11 22:23:01 by cwon             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// tail-recursive because why not
int	fibonacci_helper(int index, int prev, int result)
{
	if (index < 0)
		return (-1);
	else if (index == 0)
		return (prev);
	else if (index == 1)
		return (result);
	else
		return (fibonacci_helper(index - 1, result, prev + result));
}

int	ft_fibonacci(int index)
{
	return (fibonacci_helper(index, 0, 1));
}

#include <stdio.h>
int main()
{
	for(int i = -2; i < 10; i++)
		printf("fib(%d): %d\n", i, ft_fibonacci(i));
	return 0;
}