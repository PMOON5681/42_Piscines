/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_prime.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cwon <cwon@student.42bangkok.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/31 15:28:39 by cwon              #+#    #+#             */
/*   Updated: 2024/06/12 21:25:01 by cwon             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	int_sqrt(int nb)
{
	int		left;
	int		right;
	long	middle;

	left = 0;
	right = nb + 1;
	if (nb < 0)
		return (0);
	while (right - left > 1)
	{
		middle = left + (right - left) / 2;
		if (middle * middle < nb)
			left = middle;
		else
			right = middle;
	}
	if (right * right == nb)
		return (right);
	return (left);
}

int	ft_is_prime(int nb)
{
	int	i;
	int	limit;

	i = 2;
	limit = int_sqrt(nb);
	if (nb < 2)
		return (0);
	while (i <= limit)
	{
		if (nb % i == 0)
			return (0);
		i++;
	}
	return (1);
}

#include <stdio.h>
int main() {
	printf("listing primes: \n");
	for (int i = -2; i < 100; i++)
	{
		if(ft_is_prime(i))
			printf("%d is prime \n", i);
	}
	return 0;
}