/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cwon <cwon@student.42bangkok.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/30 20:17:09 by cwon              #+#    #+#             */
/*   Updated: 2024/06/11 22:13:01 by cwon             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_factorial(int nb)
{
	int	result;

	if (nb < 0)
		return (0);
	else if (nb == 0 || nb == 1)
		return (1);
	else
	{
		result = 1;
		while (nb)
			result *= nb--;
		return (result);
	}
}

#include <stdio.h>
int main()
{
	for(int i = -2; i < 10; i++)
		printf("%d\n", ft_iterative_factorial(i));
	return 0;
}
