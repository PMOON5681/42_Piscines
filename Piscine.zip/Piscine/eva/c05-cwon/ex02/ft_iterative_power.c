/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cwon <cwon@student.42bangkok.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/30 20:28:15 by cwon              #+#    #+#             */
/*   Updated: 2024/06/11 22:19:03 by cwon             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// exponentiation by squaring - logarithmic time!!!
int	ft_iterative_power(int nb, int power)
{
	int	odd_powers;

	odd_powers = 1;
	if (power < 0)
		return (0);
	else if (!power)
		return (1);
	else
	{
		while (power != 1)
		{
			if (power % 2)
			{
				odd_powers *= nb;
				power--;
			}
			else
			{
				nb *= nb;
				power /= 2;
			}
		}
		return (nb * odd_powers);
	}
}

#include <stdio.h>
int main()
{
	for(int i = -2; i < 10; i++)
	{
		printf("powers of %d\n", i);
		for(int j = -2; j < 10; j++)
			printf("exponent: %d, product: %d\n", j, ft_iterative_power(i, j));
		printf("\n");
	}
	return 0;
}