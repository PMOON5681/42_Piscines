/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cwon <cwon@student.42bangkok.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/30 20:22:34 by cwon              #+#    #+#             */
/*   Updated: 2024/06/11 22:13:34 by cwon             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	factorial_helper(int nb, int result)
{
	if (!nb)
		return (result);
	else
		return (factorial_helper(nb - 1, result * nb));
}

// tail-end recursive implementation
int	ft_recursive_factorial(int nb)
{
	if (nb < 0)
		return (0);
	else
		return (factorial_helper(nb, 1));
}
// // 
#include <stdio.h>
int main()
{
	for(int i = -2; i < 10; i++)
		printf("%d\n", ft_recursive_factorial(i));
	return 0;
}
