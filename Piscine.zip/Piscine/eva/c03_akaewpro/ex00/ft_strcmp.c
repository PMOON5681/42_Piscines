/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: akaewpro <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/28 01:01:09 by akaewpro          #+#    #+#             */
/*   Updated: 2024/05/30 13:36:43 by tjiranar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strcmp(char *s1, char *s2)
{
	int	i;
	//unsigned char ss = (unsigned char)s1;

	i = 0;
	while (s1[i] != '\0' || s2[i] != '\0')
	{
		if (s1[i] != s2[i])
		{
			return (s1[i] - s2[i]);
		}
		i++;
	}
	return (0);
}

#include <string.h>
#include <stdio.h>
int main()
{
	char s1[] = "\201AB";
	char s2[] = "ABC";

	printf("%d\n", strcmp(s1, s2));
	printf("%d", ft_strcmp(s1, s2));
}
