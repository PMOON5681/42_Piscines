/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcat.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: akaewpro <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/28 12:20:55 by akaewpro          #+#    #+#             */
/*   Updated: 2024/05/30 13:38:24 by tjiranar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strcat(char *dest, char *src)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	while (dest[j] != '\0')
	{
		j++;
	}
	while (src[i] != '\0')
	{
		dest[j] = src[i];
		i++;
		j++;
	}
	dest[j] = '\0';
	return (dest);
}
#include <stdio.h>
int main()
{
	char src[] = "world";
	char dest[] = "hello";
	//ft_strcat(dest, src);
	printf("%s\n", ft_strcat(dest, src));
	//printf("%s", ft_strcat(dest, src));
	//ft_strcat(dest, src);
}

