/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cchamnan <cchamnan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/27 08:27:38 by cchamnan          #+#    #+#             */
/*   Updated: 2024/05/28 10:46:58 by cchamnan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_strlen(char *str)
{
	if (!*str)
		return (0);
	return (ft_strlen(str + 1) + 1);
}

// int main()
// {
// 	char	*s;

// 	s = "hi!";

// 	printf("%d\n", ft_strlen_rec(s));
// }
