/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cchamnan <cchamnan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/27 08:03:39 by cchamnan          #+#    #+#             */
/*   Updated: 2024/05/28 11:47:16 by cchamnan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

void	swap(int *p, int *p1);

// size/2 is the "tricky" thing to grasp here
void	ft_rev_int_tab(int *tab, int size)
{
	int		swaps;
	int		i;

	i = 0;
	swaps = size / 2;
	while (swaps--)
		swap(&(*(tab + i++)), &(tab[--size]));
}

// int	main()
// {
// 	int		v[10];

// 	for (int i=0; i<10; ++i)
// 		v[i] = rand()%101;
// 	printf("\nBEFORE\n");
// 	for (int i=0; i<10; i++)
// 		printf("%d ", v[i]);
// 	printf("\n");
// 	ft_rev_int_tab(v, sizeof(v)/sizeof(v[0]));
// 	printf("\nAFTER\n");
// 	for (int i=0; i<10; i++)
// 		printf("%d ", v[i]);
// 	printf("\n\n");
// }

void	swap(int *p, int *p1)
{
	int		tmp;

	tmp = *p;
	*p = *p1;
	*p1 = tmp;
}
