/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_ft.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cchamnan <cchamnan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/27 08:27:05 by cchamnan          #+#    #+#             */
/*   Updated: 2024/05/28 08:56:23 by cchamnan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

void	ft_ultimate_ft(int *********nbr)
{
	*********nbr = 42;
}

// int main()
// {
// 	int 	n;
// 	int	*pn1;
//	int	**pn2;
//int	***pn3;
//int****pn4;
//int*****pn5;
//int******pn6;
//int*******pn7;
//int********pn8;
//int*********pn9;

// 	pn9 = &pn8;
// 	pn8 = &pn7;
// 	pn7 = &pn6;
// 	pn6 = &pn5;
// 	pn5 = &pn4;
// 	pn4 = &pn3;
// 	pn3 = &pn2;
// 	pn2 = &pn1;
// 	pn1 = &n;

// 	n = 21;
// 	printf("\nBefore the function ft_ultimate the value was %d\n", n);
// 	ft_ultimate_ft(pn9);
// 	printf("\nAfter the function now is %d\n\n", n);
// }
