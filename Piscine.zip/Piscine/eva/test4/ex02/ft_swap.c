/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_swap.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cchamnan <cchamnan@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/27 08:26:51 by cchamnan          #+#    #+#             */
/*   Updated: 2024/05/28 08:57:49 by cchamnan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_swap(int *a, int *b)
{
	int		tmp;

	tmp = *a;
	*a = *b;
	*b = tmp;
}

// int main()
// {
// 	int		n, n1;

// 	n = 42;
// 	n1 = 21;
// 	printf("before\n %d %d\n", n, n1);
// 	ft_swap(&n, &n1);
// 	printf("after\n %d %d\n", n, n1);
// }