/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tketwat <tketwat@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/31 14:34:46 by tketwat           #+#    #+#             */
/*   Updated: 2024/06/03 18:42:49 by tjiranar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_convert(int nbr, int size, char *base)
{
	if (nbr < 0)
	{
		ft_putchar('-');
		nbr = nbr * -1;
	}
	if (nbr >= size)
	{
		ft_convert(nbr / size, size, base);
	}
	ft_putchar(base[nbr % size]);
}

int	ft_check_base(char *base)
{
	int	i;

	i = 0;
	while (base[i] != '\0')
	{
		if (base[i] == base[i + 1])
			return (0);
		if (!((base[i] >= '0' && base[i] <= '9')
				|| (base[i] >= 'A' && base[i] <= 'Z')
				|| (base[i] >= 'a' && base[i] <= 'z')))
		{
			return (0);
		}
		i++;
	}
	if (i <= 1)
		return (0);
	return (1);
}

void	ft_putnbr_base(int nbr, char *base)
{
	int	size;
	int	check_base;

	size = 0;
	check_base = ft_check_base(base);
	if (check_base != 0)
	{
		size = 0;
		while (base[size] != '\0')
			size++;
		ft_convert(nbr, size, base);
	}
}

int	main(void)
{
 	int		nbr;
 	char	*base;

 	nbr = 4;
 	base = "qwertyuiopasdfghjk";
 	ft_putnbr_base(nbr, base);
 }
