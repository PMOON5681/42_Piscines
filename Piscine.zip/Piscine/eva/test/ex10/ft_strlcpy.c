/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tjiranar <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/23 22:51:35 by tjiranar          #+#    #+#             */
/*   Updated: 2024/05/28 14:47:37 by tjiranar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

unsigned int	ft_strlcpy(char *dest, char *src, unsigned int size)
{
	unsigned int	i;
	unsigned int	count;

	i = 0;
	count = 0;
	if (size < 1)
		return (count);
	while (src[count])
		count++;
	while (i < (size - 1) && src[i])
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
	return (count);
}

/*#include <stdio.h>

int	main(void)
{
	char	w[6] = "hello";
	char	w2[6] = "";
	char	*dest;
	char	*src;
	int	lenght;

	src = w;
	dest = w2;
	lenght = ft_strlcpy(dest, src,4);
	printf("%d, %s", lenght, dest);
}*/
