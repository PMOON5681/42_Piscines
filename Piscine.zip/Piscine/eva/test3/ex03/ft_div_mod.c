/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_div_mod.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sitangti <sitangti@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/28 14:30:08 by sitangti          #+#    #+#             */
/*   Updated: 2024/05/28 14:39:00 by sitangti         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <unistd.h>

void	ft_div_mod(int a, int b, int *div, int *mod)
{
	*div = a / b ;
	*mod = a % b ;
}

/* int main(){
	int a , b , div , mod ;
	
	a = 42;
	b =4;
	ft_div_mod(a,b,&div,&mod);
	printf("%d / %d = %d with %d",a,b,div,mod);
} */