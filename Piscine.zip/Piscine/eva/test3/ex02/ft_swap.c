/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_swap.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sitangti <sitangti@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/28 14:05:10 by sitangti          #+#    #+#             */
/*   Updated: 2024/05/28 14:18:40 by sitangti         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <unistd.h>

void	ft_swap(int *a, int *b)
{
	int	swap;

	swap = *a ;
	*a = *b ;
	*b = swap ;
}

/* 
int main(){
	int a , b ;

	a = 42 ;
	b = 24 ;
	ft_swap(&b, &a);
	printf("%d or %d",a,b);
} */