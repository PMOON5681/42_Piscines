/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_div_mod.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sitangti <sitangti@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/28 14:40:40 by sitangti          #+#    #+#             */
/*   Updated: 2024/05/28 14:51:17 by sitangti         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <unistd.h>

void	ft_ultimate_div_mod(int *a, int *b)
{
	int	div;
	int	mod;

	div = *a / *b ;
	mod = *a % *b ;
	*a = div ;
	*b = mod ;
}

/* int main()
{
	int a , b ;

	a = 42 ;
	b = 4 ;
	ft_ultimate_div_mod(&a,&b);
	printf("answer = %d and %d",a,b);
} */