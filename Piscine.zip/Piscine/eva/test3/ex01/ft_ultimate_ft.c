/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_ft.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sitangti <sitangti@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/28 12:28:57 by sitangti          #+#    #+#             */
/*   Updated: 2024/05/28 14:19:49 by sitangti         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <unistd.h>

void	ft_ultimate_ft(int *********nbr)
{
	*********nbr = 42 ;
}

/* int main(){
	int	n, ******pn6, *******pn7, ********pn8, *********pn9;
	int	*pn1, **pn2, ***pn3, ****pn4, *****pn5;

	pn9 = &pn8 ;
	pn8 = &pn7 ;
	pn7 = &pn6 ;
	pn6 = &pn5 ;
	pn5 = &pn4 ;
	pn4 = &pn3 ;
	pn3 = &pn2 ;
	pn2 = &pn1 ;
	pn1 = &n ;

	n = 32;
	printf("%d",n);
	ft_ultimate_ft(pn9);
	printf("\n%d",n);
} */

/* 
int main(){
	int	n;
	unsigned char	*pn;

	n =1492 ;
	pn = &n;
	for (int =i = 0; i<4; ++i)
		printf("%d\n",*(pn+i));
}
 */
