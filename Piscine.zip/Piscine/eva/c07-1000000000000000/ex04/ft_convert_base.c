/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_convert_base.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tjiranar <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/12 15:33:42 by tjiranar          #+#    #+#             */
/*   Updated: 2024/06/14 19:27:26 by tjiranar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

int	check_base(char *base)
{
	int	i;
	int	l;
	int	j;

	i = 0;
	l = ft_strlen(base);
	if (base[0] == '\0' || l == 1)
		return (0);
	while (base[i])
	{
		if (base[i] <= 32 || base[i] == 127 || base[i] == '-' || base[i] == '+')
			return (0);
		j = i + 1;
		while (base[j] != '\0')
		{
			if (base[i] == base[j])
				return (0);
			j++;
		}
		i++;
	}
	return (l);
}

int	num_to_base(char c, char *base)
{
	int	i;

	i = 0;
	while (base[i])
	{
		if (base[i] == c)
			return (i);
		i++;
	}
	return (-1);
}

int	ft_atoi(char *str, char *base, int lbase)
{
	int	i;
	int	sign;
	int	nb;
	int	j;

	i = 0;
	sign = 1;
	nb = 0;
	while (str[i] == ' ' || (str[i] >= 9 && str[i] <= 13))
		i++;
	while (str[i] == '-' || str[i] == '+')
	{
		if (str[i++] == '-')
			sign *= -1;
	}
	while (str[i])
	{
		j = num_to_base(str[i], base);
		if (j >= 0)
			nb = (nb * lbase) + j;
		else
			return (nb * sign);
		i++;
	}
	return (nb * sign);
}

int	to_base_ten(char *base, char *str)
{
	int	lbase;
	int	nb;

	lbase = check_base(base);
	if (lbase == 0)
		return (0);
	nb = ft_atoi(str, base, lbase);
	return (nb);
}
