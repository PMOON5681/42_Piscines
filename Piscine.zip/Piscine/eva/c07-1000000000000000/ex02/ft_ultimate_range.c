/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tjiranar <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/05 14:14:21 by tjiranar          #+#    #+#             */
/*   Updated: 2024/06/14 19:22:34 by tjiranar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_ultimate_range(int	**range, int min, int max)
{
	int	i;
	int	*n;

	n = (int *)malloc(sizeof(int) * (max - min));
	if (min >= max)
	{
		*range = NULL;
		return (0);
	}
	if (!n)
	{
		*range = NULL;
		return (-1);
	}
	*range = n;
	i = 0;
	while (min < max)
	{
		n[i] = min;
		min = min + 1;
		i++;
	}
	return (i);
}

#include <stdio.h>
int	main(void)
{
	int	i;
	int n;
	int	*p;

	i = -1;
	n = ft_ultimate_range(&p, -2147483648, 2147483647);
	printf("This is size of range : %d\n", n);
	while (++i < n)
		printf("This is value in the array : %d\n",p[i]);
	free(p);
	return (0);
}
