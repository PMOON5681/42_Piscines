/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sqrt.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jjeanjar <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/10 16:48:34 by jjeanjar          #+#    #+#             */
/*   Updated: 2024/06/10 16:48:58 by jjeanjar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_sqrt(int nb)
{
	int	i;

	i = 0;
	while (nb > 0)
	{
		if (i * i == nb)
			return (i);
		else if (i * i > nb)
			return (0);
		i++;
	}
	return (0);
}

#include <stdio.h>
int main(void)
{
	int i;
	i = -12345;
	printf("%d == %d\n",i,ft_sqrt(i)); 
	return (0);
}
