/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_fibonacci.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jjeanjar <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/10 16:47:33 by jjeanjar          #+#    #+#             */
/*   Updated: 2024/06/10 16:48:02 by jjeanjar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_fibonacci(int index)
{
	if (index < 0)
		return (-1);
	else if (index == 0)
		return (0);
	else if (index == 1)
		return (1);
	return (ft_fibonacci (index - 2) + ft_fibonacci (index - 1));
}

// #include <stdio.h>
// int main(void){
// 	int i = -9;
// 	while (i < 10)
// 	{
// 		printf("%d ",ft_fibonacci(i));
// 		i++;
// 	}
// }
