/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jjeanjar <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/10 16:42:08 by jjeanjar          #+#    #+#             */
/*   Updated: 2024/06/10 16:42:35 by jjeanjar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_factorial(int nb)
{
	int	mul;

	mul = 1;
	if (nb < 0)
		return (0);
	if (nb == 0 || nb == 1)
		return (1);
	while (nb > 0)
	{
		mul *= nb;
		nb --;
	}
	return (mul);
}

// #include <stdio.h>
// int main()
// {
// 	int a = ft_iterative_factorial(4);
// 	printf("%d\n", a);
// }
