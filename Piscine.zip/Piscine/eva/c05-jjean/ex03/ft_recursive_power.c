/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jjeanjar <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/10 16:46:17 by jjeanjar          #+#    #+#             */
/*   Updated: 2024/06/10 16:46:34 by jjeanjar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_recursive_power(int nb, int power)
{
	int	mul;

	mul = 1;
	if (power < 0)
		return (0);
	if (power == 0)
		return (1);
	if (power == 1)
		mul = nb;
	if (power > 1)
		mul *= nb;
	return (mul * ft_recursive_power(nb, power - 1));
}

#include <stdio.h>
int main()
{
	int a = ft_recursive_power(7, 213456789);
	printf("%d\n", a);
}
