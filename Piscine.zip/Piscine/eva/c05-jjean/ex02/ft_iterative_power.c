/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jjeanjar <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/10 16:44:41 by jjeanjar          #+#    #+#             */
/*   Updated: 2024/06/10 16:45:05 by jjeanjar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_power(int nb, int power)
{
	int	mul;

	mul = 1;
	if (power < 0)
		return (0);
	if (power == 0)
		return (1);
	while (power > 0)
	{
		mul *= nb;
		power --;
	}
	return (mul);
}

// #include <stdio.h>
// int main()
// {
// 	int a = ft_iterative_power(9, 2);
// 	printf("%d\n", a);
// }
