/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shenpras <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/28 19:17:20 by shenpras          #+#    #+#             */
/*   Updated: 2024/05/30 12:46:45 by shenpras         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_uppercase(char *str)
{
	int	u;

	u = 0;
	while (str[u] != '\0')
	{
		if (str[u] >= 'A' && str[u] <= 'B')
			return (1);
		u++;
	}
	return (0);
}

#include <stdio.h>
int	main(void)
{
	char	str1[] = "JAOAOEY";

	printf("%d", ft_str_is_uppercase(str1));

}

