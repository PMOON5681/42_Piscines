/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shenpras <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/28 18:58:57 by shenpras          #+#    #+#             */
/*   Updated: 2024/05/30 12:46:25 by shenpras         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_lowercase(char *str)
{
	int	a;

	a = 0;
	while (str[a] != '\0')
	{
		if (str[a] >= 'a' && str[a] <= 'z')
		{
			return (1);
		}
		a++;
	}
	return (0);
}

/*
#include <stdio.h>

int	main(void)
{
	char	str1[] = "FFDSF";

	printf("%d", ft_str_is_lowercase(str1));
}
*/
