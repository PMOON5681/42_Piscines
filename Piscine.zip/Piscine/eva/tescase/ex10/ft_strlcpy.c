/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shenpras <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/30 09:37:57 by shenpras          #+#    #+#             */
/*   Updated: 2024/05/30 15:37:01 by tjiranar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	len_of(char *str)
{
	int	c;

	c = 0;
	while (str[c] != '\0')
		c++;
	return (c);
}

unsigned int	ft_strlcpy(char *dest, char *src, unsigned int size)
{
	unsigned int	i;
	unsigned int	n;

	i = 0;
	n = len_of(src);
	if (size != 0)
	{
		while (dest[i] != '\0' && i < (size - 1))
		{	
			dest[i] = src[i];
			i++;
		}
		dest[i] = '\0';
	}
	return (n);
}

#include <bsd/string.h>
#include <stdio.h>
int	main(void)
{
	char	dest1[20] = "";
	char	dest2[20] = "";
	char	str1[20] = "Bello~";

	printf("%d, %s\n", ft_strlcpy(dest1, str1, 7), dest1);
	printf("%zu, %s\n,", strlcpy(dest2, str1, 7), dest2);
}

