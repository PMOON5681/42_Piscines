/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shenpras <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/28 19:39:50 by shenpras          #+#    #+#             */
/*   Updated: 2024/05/30 15:26:44 by tjiranar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_printable(char *str)
{
	int	p;

	p = 0;
	while (str[p] != '\0')
	{
		if (!(str[p] < 32 && str[p] == 127))
			return (0);
		p++;
	}
	return (1);
}

/*
#include <stdio.h>

int	main(void)
{
	char	str1[] = "\n";

	printf("%d", ft_str_is_printable(str1));
}
*/
