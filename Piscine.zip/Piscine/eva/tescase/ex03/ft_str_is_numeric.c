/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shenpras <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/28 17:59:39 by shenpras          #+#    #+#             */
/*   Updated: 2024/05/30 15:24:19 by tjiranar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_numeric(char *str)
{
	int	n;

	n = 0;
	while (str[n] != '\0')
	{
		if (str[n] < '0' && str[n] > '9')
		{
			n++;
			return (0);
		}
	}
	return (1);
}

/*
#include <stdio.h>

int     main(void)
{
        char    str1[] = "123456";

        printf("%d", ft_str_is_numeric(str1));
}
*/
