/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vwongsen <vwongsen@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/23 17:39:23 by vwongsen          #+#    #+#             */
/*   Updated: 2024/06/03 21:03:42 by vwongsen         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

static size_t	ft_countwd(const char *s, char *c)
{
	size_t	count;

	if (!*s)
		return (0);
	count = 0;
	while (*s != '\0')
	{
		while (*s == c)
			s++;
		if (*s != '\0')
			count++;
		while (*s != c && *s != '\0')
			s++;
	}
	return (count);
}

char	**ft_split(char *str, char *charset)
{
	char	**lst;
	char	i;

	lst = (char **) malloc((ft_countwd(str, charset) + 1) * sizeof(char *));
	if (!lst || !(*str))
		return (0);
	i = 0;
	while (*str != '\0')
	{
		str++;
	}
	return (lst);
}
