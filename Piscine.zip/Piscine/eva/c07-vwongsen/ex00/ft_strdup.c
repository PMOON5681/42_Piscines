/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vwongsen <vwongsen@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/23 17:39:23 by vwongsen          #+#    #+#             */
/*   Updated: 2024/06/04 16:52:16 by vwongsen         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>
char	*ft_strdup(char *src)
{
	char	*dup;
	char	*ret;
	long	len;

	len = 0;
	while (src[len] != '\0')
		len++;
	len++;
	dup = (char *) malloc(len * sizeof(char));
	printf("%p\n", dup);
	if (dup == NULL)
		return (dup);
	ret = dup;
	printf("%p\n", ret);
	while (*src)
		*dup++ = *src++;
	*dup = *src;
	
		return (ret);
}

// HEAP OK
#include <unistd.h>

#include <string.h>

int	main(void)
{
	//printf("%s\n", strdup("ABCDEF"));
	char a[] = "1111";
	//char *p = a;
	printf("%s %p\n", a, &a[0]);
	char* target = ft_strdup(a); 
	char *p2;
	p2 = target;
    printf("%s %p\n", target, p2);
	// printf("%s %p\n", target, target);
	return (0);
}