/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_convert_base.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vwongsen <vwongsen@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/23 17:39:23 by vwongsen          #+#    #+#             */
/*   Updated: 2024/06/04 17:14:32 by vwongsen         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int			find_idx(char *s, char chr);
int			ft_check_base(char *b);
char		*ft_strcat(char *s, const char *append);
char		*ft_rev_char(char *tab, int size);

int	ft_atoi(char *str, char *base, int mod)
{
	long	idx;
	long	sum;
	long	nbr;
	long	sig;

	sum = 0;
	idx = 0;
	sig = 1;
	while (str[idx] == ' ' || (str[idx] >= 9 && str[idx] <= 13))
		idx++;
	while (str[idx] == '-' || str[idx] == '+')
		if (str[idx++] == '-')
			sig *= -1;
	while (str[idx])
	{
		nbr = find_idx(base, str[idx]);
		if (nbr < 0)
			break ;
		sum = (sum * mod) + nbr;
		idx++;
	}
	return ((long)(sig * sum));
}

char	*ft_putnbr_base(int nb, char *base, int mod, char *rev)
{
	char	*ptr;
	char	sig;
	long	nbr;

	nbr = nb;
	sig = 1;
	ptr = (char *) malloc(sizeof(char));
	ptr = rev;
	if (nb < 0)
	{
		sig = -sig;
		nbr = -nbr;
	}
	while ((long)nbr > (long)0)
	{
		*rev++ = base[(long)nbr % (long)mod];
		nbr = (long)nbr / (long)mod;
	}
	if (sig < 0)
		*rev = '-';
	return (ptr);
}

char	*ft_convert_base(char *nbr, char *base_from, char *base_to)
{
	char	*output;
	char	*ptr;
	long	nb;

	if (!ft_check_base(base_from) || !ft_check_base(base_to))
		return (NULL);
	output = (char *) malloc(sizeof(char) * 64);
	if (*nbr == 0 || !output)
		return (NULL);
	ptr = output;
	nb = ft_atoi(nbr, base_from, ft_check_base(base_from));
	ptr = ft_putnbr_base(nb, base_to, ft_check_base(base_to), output);
	nb = 0;
	while (ptr[nb] != '\0')
		nb++;
	return (ft_rev_char(ptr, (int)nb));
}

#include <string.h>
#include <unistd.h>
#include <stdio.h>

int	main(int c, char *v[])
{
	if(c != 4)
	{
		printf("Invalid Arg (NB BASE_FROM BASE_TO)\n");
		printf("%s\n", ft_convert_base("10", "0123456789", "01"));
		return (0);
	}
	printf("%s\n", ft_convert_base(v[1],v[2], v[3]));
	return (0);
}
