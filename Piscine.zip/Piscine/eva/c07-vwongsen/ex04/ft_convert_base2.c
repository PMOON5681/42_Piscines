/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_convert_base2.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vwongsen <vwongsen@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/23 17:39:23 by vwongsen          #+#    #+#             */
/*   Updated: 2024/06/04 17:15:13 by vwongsen         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	find_idx(char *s, char chr)
{
	int	x;

	x = 0;
	while (*s != '\0')
	{
		if (*s == chr)
			return (x);
		x++;
		s++;
	}
	return (-1);
}

int	ft_check_base(char *b)
{
	long	idx;
	char	*ptr1;

	if (*b == 0)
		return (0);
	idx = 0;
	while (*b)
	{
		if (*b == ' ' || (*b >= 9 && *b <= 13))
			return (0);
		if (*b == '-' || *b == '+')
			return (0);
		ptr1 = b + 1;
		while (*ptr1 != 0)
		{
			if (*b == *ptr1)
				return (0);
			ptr1 = ptr1 + 1;
		}
		idx++;
		b++;
	}
	if (idx == 1)
		return (0);
	return (idx);
}

char	*ft_strcat(char *s, const char *append)
{
	char	*save;

	save = (char *) malloc(sizeof(char));
	if (save == NULL)
		return (save);
	save = s;
	while (*s != 0)
		s++;
	while (*append != 0)
		*s++ = *append++;
	*s = '\0';
	return (save);
}

char	*ft_rev_char(char *tab, int size)
{
	char	a;
	char	*ret;
	char	x;

	x = -1;
	ret = tab;
	while (x++ < (size / 2) - 1)
	{
		a = *(tab + x);
		*(tab + x) = *(tab + size - 1 - x);
		*(tab + size - 1 - x) = a;
	}
	return (ret);
}
