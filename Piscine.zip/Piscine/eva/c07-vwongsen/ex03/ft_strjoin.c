/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vwongsen <vwongsen@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/23 17:39:23 by vwongsen          #+#    #+#             */
/*   Updated: 2024/06/04 17:05:26 by vwongsen         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_strlen(char *s)
{
	int	idx;

	idx = 0;
	while (*s++)
		idx++;
	return (idx);
}

int	ft_lngh(int size, char **strs, char *sep)
{
	int	lng;

	if (size == 0)
		return (1);
	lng = (size - 1) * ft_strlen(sep);
	while (--size > -1)
		lng += ft_strlen(*strs++);
	return (lng + 1);
}

char	*ft_strcat(char *s, const char *append)
{
	char	*save;

	save = s;
	while (*s != '\0')
		s++;
	while (*append != '\0')
		*s++ = *append++;
	*s = *append;
	return (save);
}

char	*ft_strjoin(int size, char **strs, char *sep)
{
	char	*word;
	long	idx;
	char	*ptr;

	if (size == 0)
	{
		word = NULL;
		return (word);
	}
	idx = ft_lngh(size, strs, sep);
	word = (char *) malloc(sizeof(char) * idx);
	if (word == NULL)
		return (word);
	ptr = word;
	word = ft_strcat(word, strs[0]);
	idx = 0;
	while (++idx < (long)size)
	{
		word = ft_strcat(word, sep);
		word = ft_strcat(word, strs[idx]);
	}
	return (ptr);
}

#include <unistd.h>
#include <stdio.h>

int	main(void)
{
	char	*ptr;
	char	sep[] = "/";
	
	ptr = (char *) malloc(sizeof(char) * 100);

	char *strs[2];
	strs[0] = "he";
	strs[1] = "llo";

	ptr = ft_strjoin(2, strs, sep);
	if(ptr == NULL){
		free(ptr);
		return 0;
	}
	printf("JOIN %s- SEP %s\n", ptr, sep);
	printf("P %p\n", ptr);

	ptr = ft_strjoin(2, strs, sep);
	// if(!ptr)
	// 	return 0;
	printf("JOIN %s  - SEP %s\n", ptr, sep);
	printf("P %p %s\n", ptr, ptr);
	free(ptr);
	printf("FREE P %p %s\n", ptr, ptr);
	return (0);
}
