/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vwongsen <vwongsen@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/23 17:39:23 by vwongsen          #+#    #+#             */
/*   Updated: 2024/06/03 10:26:16 by vwongsen         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	*ft_range(int min, int max)
{
	int	*array;
	int	idx;

	if (min >= max)
		return (NULL);
	array = (int *) malloc(sizeof(int) * (max - min));
	if(!array)
		return (0);
	idx = 0;
	while (min < max)
	{
		array[idx++] = min;
		min++;
	}
	return (array);
}
/*
#include <unistd.h>
#include <stdio.h>

int	main(void)
{
	int	*ptr;
	int	min;
	int	max;
	int	idx;

	min = -5;
	max = 5;
	idx = -1;
	if (min >= max)
		return (0);
	ptr = (int *) malloc(sizeof(int) * (max - min));
	ptr = ft_range(min, max);
	while (++idx < (max - min))
	{
		printf("%d %d\n", idx, ptr[idx]);
	}
	free(ptr);
	return (0);
}
*/