/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cwon <cwon@student.42bangkok.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/23 13:33:11 by cwon              #+#    #+#             */
/*   Updated: 2024/05/28 14:41:29 by cwon             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

// precondition: char str is a c-string, meaning null char terminated
void	ft_putstr(char *str)
{
	char	*ptr;

	ptr = str;
	while (ptr && *ptr != '\0')
	{
		write(1, ptr, 1);
		ptr++;
	}
	if (ptr && *ptr == '\0')
		write(1, ptr, 1);
}
