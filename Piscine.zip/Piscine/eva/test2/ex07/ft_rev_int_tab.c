/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cwon <cwon@student.42bangkok.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/23 13:50:57 by cwon              #+#    #+#             */
/*   Updated: 2024/05/26 21:31:56 by cwon             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// precondition: arr is not null pointer
void	swap(int *arr, int i, int j)
{
	int	temp;

	temp = arr[i];
	arr[i] = arr[j];
	arr[j] = temp;
}

void	ft_rev_int_tab(int *tab, int size)
{
	int	i;

	if (tab)
	{
		i = 0;
		while (i < size / 2)
		{
			swap(tab, i, size - i - 1);
			i++;
		}
	}
}
