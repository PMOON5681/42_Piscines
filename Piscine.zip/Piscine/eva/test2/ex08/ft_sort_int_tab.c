/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cwon <cwon@student.42bangkok.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/23 13:57:47 by cwon              #+#    #+#             */
/*   Updated: 2024/05/28 16:07:34 by tjiranar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// for non-neg ints a and b, a + (b - a)/2 prevents
// overflow in average calculation.
int	middle_index(int left, int right)
{
	return (left + (right - left) / 2);
}

// precondition: start and end are within range of arr, arr is not null ptr
// postcondition: right-cycle of arr
void	right_shift(int *arr, int start, int end)
{
	int	temp;

	temp = arr[end];
	while (start < end)
	{
		arr[end] = arr[end - 1];
		end--;
	}
	arr[end] = temp;
}

// precondition: arr is not null pointer
void	merge(int *arr, int left, int right)
{
	int	middle;
	int	i;

	middle = middle_index(left, right);
	i = middle + 1;
	if (arr[middle] > arr[i])
	{
		while (left <= middle && i <= right)
		{
			if (arr[left] <= arr[i])
				left++;
			else
			{
				right_shift(arr, left, i);
				left++;
				middle++;
				i++;
			}
		}
	}
}

// precondition: arr is not null pointer
void	merge_sort(int *arr, int left, int right)
{
	int	middle;

	if (left < right)
	{
		middle = middle_index(left, right);
		merge_sort(arr, left, middle);
		merge_sort(arr, middle + 1, right);
		merge(arr, left, right);
	}
}

void	ft_sort_int_tab(int *tab, int size)
{
	if (tab)
		merge_sort(tab, 0, size - 1);
}

#include <stdio.h>
int	main()
{
	int	a[] = {4,5,6,2,5,1,0};
	ft_sort_int_tab(a, 7);
	int i = 0;
	while (i < 7){
	printf("%d",a[i]);
	i++;}
}
