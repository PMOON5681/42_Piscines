/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cwon <cwon@student.42bangkok.com>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/23 13:41:30 by cwon              #+#    #+#             */
/*   Updated: 2024/05/28 14:42:07 by cwon             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

// also needs to be null char terminated otherwise the length is not accurate
int	ft_strlen(char *str)
{
	int		length;
	char	*ptr;

	length = 0;
	ptr = str;
	while (ptr && *ptr != '\0')
	{
		length++;
		ptr++;
	}
	return (length);
}
