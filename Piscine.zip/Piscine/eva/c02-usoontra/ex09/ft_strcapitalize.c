/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: usoontra <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/28 17:24:46 by usoontra          #+#    #+#             */
/*   Updated: 2024/05/30 19:49:23 by tjiranar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_strcapitalize(char *str)
{
	int	i;
	int	new_word;

	i = 0;
	new_word = 1;
	while (str[i] != '\0')
	{
		if (new_word == 1 && str[i] >= 'a' && str[i] <= 'z')
			str[i] -= 32;
		if (new_word == 0 && str[i] >= 'A' && str[i] <= 'Z')
			str[i] += 32;
		if (str[i] < '0' || (str[i] > '9' && str[i] < 'A'))
			new_word = 1;
		else if ((str[i] > 'Z' && str[i] < 'a') || str[i] > 'z')
			new_word = 1;
		else
			new_word = 0;
		i++;
	}
	return (str);
}

int	main(void)
{
	char	a[] = " a , cUont tu vas ? 42Mots";

	printf("%s\n", a);
	printf("%s", ft_strcapitalize(a));
}
