/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: usoontra <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/29 13:36:52 by usoontra          #+#    #+#             */
/*   Updated: 2024/05/30 19:53:48 by tjiranar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

unsigned int	ft_strlcpy(char *dest, char *src, unsigned int size)
{
	unsigned int	i;
	unsigned int	len;

	i = 0;
	len = 0;
	while (src[i] != '\0')
	{
		len++;
		i++;
	}
	if (len == 0)
	{
		return (len);
	}
	i = 0;
	while (src[i] != '\0' && i < (size - 1))
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
	return (len);
}

//#include <bsd/string.h>

int	main(void)
{
	char	a[] = "dfg";
//	char	c[] = "dfghjk";
	char	b[] = "yguji";

	printf("a = %s\nb = %s\n", a, b);
	printf("a = %d\n, %s", ft_strlcpy(a, b, 6), a);
//	printf("%ld, %s",strlcpy(c, b, 6), c );
}
