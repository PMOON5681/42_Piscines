/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gpheepho <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/04 10:25:08 by gpheepho          #+#    #+#             */
/*   Updated: 2024/06/04 14:29:07 by gpheepho         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned int	ft_strlcpy(char *dest, char *src, unsigned int size)
{
	unsigned int	i;
	unsigned int	count;

	i = 0;
	count = 0;

	while (src[i] != '\0')
	{
		i++;
		count++;
	}
	if (size < 1)
	{
		return (count);
	}
	i = 0;
	while ((src[i] != '\0') && (i < size - 1))
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
	return (count);
}

#include <bsd/string.h>
#include <stdio.h>

int main(void)
{
    //unsigned int ssize = 8;
    char s[] = "sourcecode";
    char d[] = "";
	char r[] = "";
    int a;

    a = ft_strlcpy(d,s,8);
	int b = strlcpy(r, s, 8);
    printf("%d : %s\n%d : %s",a, d, b ,r);
    //printf("%s",d);
}
