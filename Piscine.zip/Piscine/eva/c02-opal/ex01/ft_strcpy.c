/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gpheepho <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/31 18:00:51 by gpheepho          #+#    #+#             */
/*   Updated: 2024/06/04 13:53:07 by gpheepho         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	unsigned int	i;

	i = 0;
	if (src[i] == '\0')
	{
		return (0);
	}
	while (src[i] != '\0' && i < n)
	{
		dest[i] = src[i];
		i++;
	}
	return (dest);
}

// #include <stdio.h>
// int main(void)
// {
//     char d[] = "try";
//     char s[] = "everything_too";
//     ft_strncpy(d,s,10);
//     printf("%s",d);
// }