/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strupcase.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gpheepho <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/03 16:16:32 by gpheepho          #+#    #+#             */
/*   Updated: 2024/06/04 14:18:06 by gpheepho         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strupcase(char *str)
{
	int	i;

	i = -1;
	while (str[++i])
	{
		if (str[i] >= 'a' && str[i] <= 'z')
			str[i] = str[i] - 32;
	}
	return (str);
}

#include <stdio.h>

int main(void)
{
    char input[] = "ad!~T";
    char input1[] = "myMoney is bROke";

    ft_strupcase(input);
    ft_strupcase(input1);

	printf("%s\n", input);
    printf("%s", input1);
}
