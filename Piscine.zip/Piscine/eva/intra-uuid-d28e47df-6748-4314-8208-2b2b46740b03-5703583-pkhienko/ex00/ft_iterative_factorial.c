/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pkhienko <pkhienko@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/29 22:25:43 by pkhienko          #+#    #+#             */
/*   Updated: 2024/05/30 21:02:23 by tjiranar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_iterative_factorial(int nb)
{
	int	i;
	int	j;
	int	k;

	i = 1;
	j = nb;
	k = nb;
	if (nb < 1)
		return (0);
	while (i < nb)
	{
		j *= (k - i);
		i++;
	}
	return (j);
}

#include <stdio.h>

 int main()
 {
 	printf("%d", ft_iterative_factorial(5));
}
