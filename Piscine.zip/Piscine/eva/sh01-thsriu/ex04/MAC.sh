#!/bin/sh
ifconfig -a | grep -Po 'ether \K([a-fA-F0-9\:]++)'
