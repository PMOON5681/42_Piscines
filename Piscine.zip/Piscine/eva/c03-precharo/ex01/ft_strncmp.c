/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: precharo <precharo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/28 15:03:32 by precharo          #+#    #+#             */
/*   Updated: 2024/06/01 15:37:22 by precharo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>

int	ft_strncmp(char *s1, char *s2, unsigned int n)
{
	unsigned int	i;
	unsigned char	a1;
	unsigned char	a2;

	i = 0;
	while ((s1[i] != '\0' || s2[i] != '\0') && i < n)
	{
		a1 = (unsigned char)s1[i];
		a2 = (unsigned char)s2[i];
		if (a1 != a2)
			return (a1 - a2);
		i++;
	}
	return (0);
}

/*#include <string.h>
int	main()
{
	char	*str1;
	char	*str2;
	//int		c1;
	//int		c2;

	str1 = "";
	str2 = "\200";
	//c1 = ft_strncmp(str1, str2, 5);
	//c2 = strncmp(str1, str2, 5);
//	if (c1 == c2)
//	{
//		printf("%s\n", "equal");
//	}
	printf("%d\n", strncmp(str1, str2, 10));
	printf("%d\n", ft_strncmp(str1, str2, 10));
}*/
