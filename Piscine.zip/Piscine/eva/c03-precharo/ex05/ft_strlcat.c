/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: precharo <precharo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/28 16:43:34 by precharo          #+#    #+#             */
/*   Updated: 2024/06/01 17:21:06 by tjiranar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_strlen(char *str)
{
	int	count;
	int	i;

	count = 0;
	i = 0;
	while (str[i] != '\0')
	{
		count++;
		i++;
	}
	return (count);
}

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int	dest_len;
	unsigned int	src_len;
	unsigned int	i;

	i = 0;
	dest_len = ft_strlen(dest);
	src_len = ft_strlen(src);
	if (dest_len >= size)
		return (size + src_len);
	while ((i < size - 1) && (src[i] != '\0'))
	{
		dest[dest_len + i] = src[i];
		i++;
	}
	dest[dest_len + i - 1] = '\0';
	return (dest_len + src_len);
}

#include <bsd/string.h>
int	main()
{
	char	dest[9] = "this is ";
	//char	dest2[9] = "this is ";
	char	src[3] = "St";
	char	*s1;
	//char	*s2;
	char	*s3;
	int	r;

	s1 = dest;
	//s2 = dest2;
	s3 = src;

	r = ft_strlcat(s1, s3, 10);
	printf("%d, %s\n",r, dest);
	
	// r = ft_strlen(dest);
	// printf("%d\n", r);
	// r = ft_strlen(src);
	// printf("%d", r);
}
