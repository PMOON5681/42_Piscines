/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: precharo <precharo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/29 12:15:54 by precharo          #+#    #+#             */
/*   Updated: 2024/06/01 17:11:09 by tjiranar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_strlen(char *str)
{
	int	count;

	count = 0;
	while (*str != '\0')
	{
		count++;
		str++;
	}
	return (count);
}

char	*ft_strstr(char *str, char *to_find)
{
	int	i;
	//int	p;
	int	j;

	i = 0;
	if (*to_find == '\0')
		return (str);
	while (str[i] != '\0')
	{
		j = 0;
		//p = 0;
		while (to_find[j] != '\0' && str[i + j] == to_find[j])
		{
			if (j == ft_strlen(to_find) - 1)
				return (&str[i]);
			//p++;
			j++;
		}
		i++;
	}
	return (0);
}
#include <string.h>
int main()
{
	printf("%s\n", ft_strstr("Hello World", "e"));
	printf("%s\n", strstr("Hello World", "e"));
}
