/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: shenpras <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/28 17:59:39 by shenpras          #+#    #+#             */
/*   Updated: 2024/05/30 12:45:57 by shenpras         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_numeric(char *str)
{
	int	n;

	n = 0;
	while (str[n] != '\0')
	{
		if (str[n] >= '9' && str[n] <= '0')
		{
			n++;
			return (1);
		}
	}
	return (0);
}

/*
#include <stdio.h>

int     main(void)
{
        char    str1[] = "123456";

        printf("%d", ft_str_is_numeric(str1));
}
*/
