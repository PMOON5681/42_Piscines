#ifndef STR_H
# define STR_H

void 	putstr(char *str);
int	    ft_strlen(char *c);
char	*ft_strcpy(char	*src, char *dest);
char	*ft_strdup(char *src);

void dict_put_value(char *buffer, char key[100][100]);
void dict_put_key(char *buffer, char key[100][100]);

#endif