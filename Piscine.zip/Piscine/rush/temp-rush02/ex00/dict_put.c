void dict_put_value(char *buffer, char key[100][100]);
void dict_put_key(char *buffer, char key[100][100]);


void dict_put_key(char *buffer, char key[100][100])
{
	int i = 0;
	int j = 0;
	int c = 0;
	while (buffer[i])
	{
		c = 0;
		while (buffer[i] != ':')
		{
			key[j][c] = buffer[i];
			c++;
			i++;
		}
		i += 2;
		c = 0;
		while (buffer[i] != '\n')
		{
			c++;
			i++;
		}
		j++;
		i++;	
	}
}

void dict_put_value(char *buffer, char key[100][100])
{
	int i = 0;
	int j = 0;
	int c = 0;
	while (buffer[i])
	{
		c = 0;
		while (buffer[i] != ':')
		{
			c++;
			i++;
		}
		i += 2;
		c = 0;
		while (buffer[i] != '\n')
		{
			key[j][c] = buffer[i];
			c++;
			i++;
		}
		j++;
		i++;	
	}
}