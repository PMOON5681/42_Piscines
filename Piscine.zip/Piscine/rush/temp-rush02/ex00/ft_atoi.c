/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: supanuso <supanuso@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/08 14:27:47 by supanuso          #+#    #+#             */
/*   Updated: 2024/06/08 17:55:26 by supanuso         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

typedef struct input
{
	int		value;
	int		len;
}	input_value;

int	error(void)
{
	write(1, "Error\n", 6);
	return (0);
}

int	ft_len_num(char *str)
{
	int len;

	len = 0;
	while (*str && *str >= '0' && *str <= '9')
	{
		str++;
		len++;
	}
	return (len);
}

int	check_sym_arg(char *str, int *to_i)
{
	int	j;
	int	i;
	int	np;

	i = 0;
	j = 1;
	np = 1;
	while ((str[i] >= '\t' && str[i] <= '\r') || str[i] == ' ')
		i++;
	while (str[i] != '\0' && j == 1)
	{
		if (str[i] == '-' || str[i] == '+')
		{
			if (str[i] == '-')
				np *= -1;
		}
		else
			j = 0;
		i++;
	}
	*to_i = i-1;
	return (np);
}

input_value	*ft_putvalue(int argc, char *argv)
{
	int			i;
	int			j;
	int			input_len;
	input_value	*input;

	i = 0;
	j = 0;
	if (check_sym_arg(argv, &i) == -1)
		error();
	input_len = ft_len_num(argv + i);
	input = (input_value*)malloc(sizeof(input_value) * input_len);
	while (input_len > 0)
	{
		input[j].value = argv[i+j] - '0';
		input[j].len = input_len;
		printf("%d\n", input[j].value);
		j++;
		input_len--;
	}
	return (input);
}

int	main(int argc, char **argv)
{
	input_value *print;

	if (argc < 2 || argc > 3)
		error();
	else
	{
		print = ft_putvalue(argc, argv[argc-1]);
	}
}
