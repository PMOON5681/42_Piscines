
#include "header.h"
#include <string.h>
//#include "dict_put.h"

#define BUF_SIZE 4096

// void dict_put_value(char *buffer, char key[100][100]);
// void dict_put_key(char *buffer, char key[100][100]);
// void 	putstr(char *str);
// int	ft_strlen(char *c);
// char	*ft_strcpy(char	*src, char *dest);
// char	*ft_strdup(char *src);
// char	**ft_dictcpy(char	*src, char *dest);

// char *file_read(char *file)
// {
// 	int fd;
// 	char *buffer;
// 	ssize_t bytes_file;

// 	//	bytes_file = file_size(file);
// 	bytes_file = BUF_SIZE;
// 	if (bytes_file == -1)
// 	{
// 		printf("Error Number %d\n", fd);
// 		perror("Program");
// 	}

// 	fd = open(file, O_RDONLY);
// 	buffer = (char *)malloc(bytes_file); // assign buffer range
// 	bytes_file = read(fd, buffer, bytes_file);
// 	if (bytes_file == -1)
// 	{
// 		printf("Error Number %d\n", fd);
// 		perror("Program");
// 	}
// 	close(fd);
// 	return (buffer);
// }

void	find_digit(char *str)
{
	int	srclen;
	int	digit;

	srclen = ft_strlen(str);
	digit = src / 3;
}

int main(int ac, char **av)
{
	// char *file;
	// char *buffer;
	// char key[100][100];
	// char value[100][100];
	// int i;

	// i = 0;
	// file = "numbers.dict";
	// buffer = file_read(file);
	// dict_put_key(buffer, key);
	// dict_put_value(buffer, value);
	// while (++i < 41) // test
	// 	printf("%s : %s\n", key[i], value[i]);
	// return (0);

	int	srclen;

	if(ac == 2)
	{
		find_digit(av[1])
	}
	else if (ac == 3)
	{

	}
	else
	{
		
		return (0);
	}
}
