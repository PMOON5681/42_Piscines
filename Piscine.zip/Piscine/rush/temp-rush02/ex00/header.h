/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   header.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tjiranar <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/08 16:16:24 by tjiranar          #+#    #+#             */
/*   Updated: 2024/06/08 18:21:25 by tjiranar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HEADER_H
# define HEADER_H

# include <unistd.h>
# include <stdlib.h>
# include <fcntl.h>
# include <stdio.h>

typedef struct s_dict
{
	char    *key; //number
	char    *value; //value
}   t_dict;

typedef struct input
{
		int	value;
		int	len;
}       input_value;

void	ft_putchar(char c);
void ft_putstr(char *str);
int ft_strlen(char *str);

void dict_put_value(char *buffer, char key[100][100]);
void dict_put_key(char *buffer, char key[100][100]);


#endif
