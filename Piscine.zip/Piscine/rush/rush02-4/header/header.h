/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   header.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tjiranar <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/09 19:57:17 by tjiranar          #+#    #+#             */
/*   Updated: 2024/06/09 20:04:37 by tjiranar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef header.h
# define header.h

# include <unistd.h>
# include <stdlib.h>
# include <fcntl.h>

int	ft_strlen(char *str);
int	ft_strstr(char *str, char *to_find);
char	*ft_itoa(int nbr);
char	*ft_strdup(char *src);

char	**get_dict(int	fo);
char	**parse_file(char *file);
void	iterate_dict(int *i, int *j);

#endif
