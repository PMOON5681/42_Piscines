/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   header.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: asudyodd <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/09 16:21:28 by asudyodd          #+#    #+#             */
/*   Updated: 2024/06/09 16:38:14 by asudyodd         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HEADER_H
# define HEADER_H

#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <error.h>
#include <stdio.h>

typedef struct s_dict
{
	char    *key;
	char    *value;
}	t_dict;

typedef struct s_input
{
	int	num;
	int	set;
}   t_input;

void	dict_put(char *buffer, t_dict *dict);
void	putstr(char *str);
char	*ft_strcpy(char	*src, char *dest);
char	*ft_strdup(char *src);
int		ft_strlen(char *c);
void	putstr(char *str);
#endif
