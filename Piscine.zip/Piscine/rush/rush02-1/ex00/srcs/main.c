/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: asudyodd <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/09 16:25:16 by asudyodd          #+#    #+#             */
/*   Updated: 2024/06/09 16:25:41 by asudyodd         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

#define BUF_SIZE 4096

char *file_read(char *file)
{
	int fd;
	char *buffer;
	ssize_t bytes_file;

	//	bytes_file = file_size(file);
	bytes_file = BUF_SIZE;
	if (bytes_file == -1)
	{
		printf("Error Number %d\n", fd);
		perror("Program");
	}

	fd = open(file, O_RDONLY);
	buffer = (char *)malloc(bytes_file); // assign buffer range
	bytes_file = read(fd, buffer, bytes_file);
	if (bytes_file == -1)
	{
		printf("Error Number %d\n", fd);
		perror("Program");
	}
	close(fd);
	return (buffer);
}


int main(void)
{
	char *file;
	char *buffer;
	char key[100][100];
	char value[100][100];
	int i;

	i = 0;
	file = "dictionary/numbers.dict";
	buffer = file_read(file);
	dict_put_key(buffer, key);
	dict_put_value(buffer, value);
	while (++i < 41) // test
		printf("%s : %s\n", key[i], value[i]);
	
	return (0);
}
