/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   str.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: asudyodd <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/09 16:20:08 by asudyodd          #+#    #+#             */
/*   Updated: 2024/06/09 16:34:48 by asudyodd         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

void	putstr(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i++;
	write(1, str, i);
}

int	ft_strlen(char *c)
{
	int	count;

	count = 0;
	while (*c != '\0')
	{
		c++;
		count++;
	}
	return (count);
}

char	*ft_strcpy(char	*src, char *dest)
{
	int	i;

	i = 0;
	while (src[i] != '\0')
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
	return (dest);
}

char	*ft_dictcpy(char *buffer, char **key)
{
	int	i;
	int	j;
	int	c;

	i = 0;
	j = 0;
	while (buffer[i])
	{
		c = 0;
		while (buffer[i] != ':')
		{
			key[j][c] = buffer[i];
			c++;
			i++;
		}
		i += 2;
		c = 0;
		while (buffer[i] != '\n')
		{
			c++;
			i++;
		}
		j++;
		i++;
	}
	return (0);
}

char	*ft_strdup(char *src)
{
	char	*ptr;

	ptr = (char *)malloc((ft_strlen(src) * sizeof(char)) + 1);
	return (ft_strcpy(src, ptr));
}
