/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   dict_put.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: asudyodd <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/09 16:24:06 by asudyodd          #+#    #+#             */
/*   Updated: 2024/06/09 16:31:28 by asudyodd         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

void	dict_put_key(char *buffer, char key[100][100])
{
	int	i;
	int	j;
	int	c;

	i = 0;
	j = 0;
	while (buffer[i])
	{
		c = 0;
		while (buffer[i] != ':')
		{
			key[j][c] = buffer[i];
			c++;
			i++;
		}
		i += 2;
		c = 0;
		while (buffer[i] != '\n')
		{
			c++;
			i++;
		}
		j++;
		i++;
	}
}

void	dict_put_value(char *buffer, char key[100][100])
{
	int	i;
	int	j;
	int	c;

	i = 0;
	j = 0;
	while (buffer[i])
	{
		c = 0;
		while (buffer[i] != ':')
		{
			c++;
			i++;
		}
		i += 2;
		c = 0;
		while (buffer[i] != '\n')
		{
			key[j][c] = buffer[i];
			c++;
			i++;
		}
		j++;
		i++;
	}
}
