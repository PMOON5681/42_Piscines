/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_dict.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sisingja <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/08 21:21:33 by sisingja          #+#    #+#             */
/*   Updated: 2024/06/08 21:33:27 by sisingja         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush.h"

static char	*add_letter(char *str, char c)
{
	int		i;
	char	*new;

	new = (char *)malloc((ft_strlen(str) + 2) * sizeof(char));
	i = 0;
	if (str)
	{
		while (str[i])
		{
			new[i] = str[i];
			i++;
		}
	}
	if (str)
		free(str);
	new[i++] = c;
	new[i] = '\0';
	return (new);
}

static char	*get_file(int find)
{
	char	c;
	char	*file;

	c = '*';
	file = NULL;
	while (read(find, &c, 1) > 0 && c)
	{
		file = add_letter(file, c);
	}
	return (file);
}

char	**get_dict(int find)
{
	char	**dict;
	char	*file;

	file = get_file(find);
	dict = parse_file(file);
	free(file);
	return (dict);
}
