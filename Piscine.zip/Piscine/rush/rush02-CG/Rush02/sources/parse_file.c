/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse_file.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sisingja <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/08 21:37:00 by sisingja          #+#    #+#             */
/*   Updated: 2024/06/08 22:08:17 by sisingja         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush.h"

static int	get_def_size(char *str)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	while (str[i] && str[i] >= 32 && str[i] <= 126)
	{
		i++;
		j++;
		if (str[i] == ' ')
			j++;
		while (str[i] == ' ')
			i++;
	}
	return (j + 1);
}

static char	*get_def(char *str)
{
	int	i;
	int	j;
	char	*def;

	def = (char *)malloc(get_def_size(str) * sizeof(char));
	i = 0;
	j = 0;
	while (str[i] && str[i] != '\n')
	{
		def[j] = str[i];
		i++;
		j++;
		if (str[i] == ' ')
			def[j++] = str[i];
		while (str[i] == ' ')
			i++;
	}
	def[j] = '\0';
	return (def)
}

static char	*find_def(char *word, char *file)
{
	int	i;
	char	*def;

	i = ft_strstr(file, word);
	if (i < 0)
		return (NULL);
	while (file[i] != ':')
		i++;
	i++;
	while (file[i] == ' ')
		i++;
	if (file[i] < 33 || file[i] > 126)
		return (NULL);
	def = get_def(&file[i]);
	return (def);
}

static void	*big_num(char **dict, int j, char *file)
{
	if (!(dico[j++] = find_def("1000", file)))
		return (free_dico(dico, j - 2));
	if (!(dico[j++] = find_def("1000000", file)))
		return (free_dico(dico, j - 2));
	if (!(dico[j++] = find_def("1000000000", file)))
		return (free_dico(dico, j - 2));
	if (!(dico[j++] = find_def("1000000000000", file)))
		return (free_dico(dico, j - 2));
	if (!(dico[j++] = find_def("1000000000000000", file)))
		return (free_dico(dico, j - 2));
	if (!(dico[j++] = find_def("1000000000000000000", file)))
		return (free_dico(dico, j - 2));
	if (!(dico[j++] = find_def("1000000000000000000000", file)))
		return (free_dico(dico, j - 2));
	if (!(dico[j++] = find_def("1000000000000000000000000", file)))
		return (free_dico(dico, j - 2));
	if (!(dico[j++] = find_def("1000000000000000000000000000", file)))
		return (free_dico(dico, j - 2));
	if (!(dico[j++] = find_def("1000000000000000000000000000000", file)))
		return (free_dico(dico, j - 2));
	if (!(dico[j++] = find_def("1000000000000000000000000000000000", file)))
		return (free_dico(dico, j - 2));
	if (!(dico[j++] = find_def("1000000000000000000000000000000000000", file)))
		return (free_dico(dico, j - 2));
	return (&dico[0]);
}

char	**parse_file(char *file)
{
	char	*word;
	char	**dict;
	int	i;
	int	j;

	dict = (char **)malloc(42 * sizeof(char *));
	i = 0;
	j = 0;
	while (i <= 100)
	{
		word = ft_itoa(i);
		dict[j] = find_dict(word, file);
		if (!(dict[i]))
			return (free_dict(dict, j - 1));
		j++;
		free(word);
		if (i < 20)
			i = i + 1;
		else
			i = i + 10;
		if (!big_num(dict, j, file))
			return (NULL);
		dict[41] = NULL;
		return (dict);
}
