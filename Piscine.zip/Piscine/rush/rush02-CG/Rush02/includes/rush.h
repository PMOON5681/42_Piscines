/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush.h                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sisingja <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/08 20:59:33 by sisingja          #+#    #+#             */
/*   Updated: 2024/06/08 21:14:48 by sisingja         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef RUSH_H
# define RUSH_H

# include "unistd.h"
# include "stdlib.h"
# include "sys/stat.h"
# include "sys/types.h"
# include "fcntl.h"
# include "stdio.h"

char	**get_dict(int find);
int	ft_strlen(char *str);
int	ft_strstr_(char *str, char *to_find);
char	**parse_file(char *file);
char	*ft_itoa(int nbr);
int	check_nb(char *nb);
void	print_nb(char *nb, char **dict);
void	*free_dict(char **dict, int j);
char	**make_intern_dict(void);
void	print_unity(char *nb, char **dict, int *i);

#endif
