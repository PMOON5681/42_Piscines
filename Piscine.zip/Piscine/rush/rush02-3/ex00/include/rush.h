/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush.h                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pibasri <pibasri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/09 11:33:35 by pibasri           #+#    #+#             */
/*   Updated: 2024/06/09 19:14:45 by tjiranar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef RUSH_H
# define RUSH_H

# include <unistd.h>
# include <stdlib.h>
# include <fcntl.h>

int	ft_strlen(char *str);
int	ft_strstr(char *str, const char *to_find);
char	*ft_itoa(int nbr);
char	*ft_strdup(char *src);

char	**get_dico(int fd);
char	**parse_file(char *file);
void	iterate_dict(int *i, int *j);

void	zero_cutter(char *nb, char **ref);
void	print_nb(char *nb, char **dico);
void	print_unity(char *nb, char **dico, int *i);

int	    check_arg(int argc, char **argv, char **num);
int	    dict_not_found(char *num);

void	*free_dico(char **dico, int j);
void	release(char **dico, int j, int fd);

#endif
