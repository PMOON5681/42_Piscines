/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   error_catch.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pibasri <pibasri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/08 22:42:27 by pibasri           #+#    #+#             */
/*   Updated: 2024/06/09 13:40:52 by pibasri          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/rush.h"

static int	check_nb(char *nb)
{
	int	len;

	len = 0;
	while (nb[len])
	{
		if (!(nb[len] >= '0' && nb[len] <= '9'))
			return (0);
		len++;
	}
	if (len > 39)
		return (0);
	return (len);
}

int	check_arg(int argc, char **argv, char **num)
{
	if (argc == 1 || argc > 3)
		return (0);
	if (argc == 2)
		*num = argv[1];
	else
		*num = argv[2];
	zero_cutter(*num, num);
	if (!check_nb(*num))
	{
		free(*num);
		return (0);
	}
	return (1);
}
