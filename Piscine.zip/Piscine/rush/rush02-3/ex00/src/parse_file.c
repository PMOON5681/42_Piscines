/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse_file.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pibasri <pibasri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/09 11:34:42 by pibasri           #+#    #+#             */
/*   Updated: 2024/06/09 12:52:00 by pibasri          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/rush.h"

static int	get_def_size(char *str)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	while (str[i] && str[i] >= 32 && str[i] <= 126)
	{
		i++;
		j++;
		if (str[i] == ' ')
			j++;
		while (str[i] == ' ')
			i++;
	}
	return (j + 1);
}

static char	*get_def(char *str)
{
	int		i;
	int		j;
	char	*def;

	def = (char *) malloc(get_def_size(str) * sizeof(char));
	i = 0;
	j = 0;
	while (str[i] && str[i] != '\n')
	{
		def[j] = str[i];
		i++;
		j++;
		if (str[i] == ' ')
			def[j++] = str[i];
		while (str[i] == ' ')
			i++;
	}
	def[j] = '\0';
	return (def);
}

static char	*find_def(const char *word, char *file)
{
	int		i;
	char	*def;

	i = ft_strstr(file, word);
	if (i < 0)
		return (NULL);
	while (file[i] != ':')
		i++;
	i++;
	while (file[i] == ' ')
		i++;
	if (file[i] < 33 || file[i] > 126)
		return (NULL);
	def = get_def(&file[i]);
	return (def);
}

static void	*big_num(char **dico, int j, char *file)
{
	int				i;
	int				num_count;
	const char		*numbers[] = {
		"1000", "1000000", "1000000000", "1000000000000",
		"1000000000000000", "1000000000000000000",
		"1000000000000000000000", "1000000000000000000000000",
		"1000000000000000000000000000", "1000000000000000000000000000000",
		"1000000000000000000000000000000000",
		"1000000000000000000000000000000000000"
	};

	i = 0;
	num_count = sizeof(numbers) / sizeof(numbers[0]);
	while (i < num_count)
	{
		dico[j] = find_def(numbers[i], file);
		if (dico[j] == NULL)
			return ((free_dico(dico, j - 1)));
		j++;
		i++;
	}
	return (&dico[0]);
}

char	**parse_file(char *file)
{
	int		i;
	int		j;
	char	*word;
	char	**dico;

	i = 0;
	j = 0;
	dico = (char **) malloc(100 * sizeof(char *));
	if (!dico)
		return (NULL);
	while (i <= 100)
	{
		word = ft_itoa(i);
		if (!word)
			return (free_dico(dico, j - 1));
		dico[j] = find_def(word, file);
		free(word);
		if (!(dico[j]))
			return (free_dico(dico, j - 1));
		iterate_dict(&i, &j);
	}
	if (!big_num(dico, j, file))
		return (NULL);
	dico[99] = NULL;
	return (dico);
}
