/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_unity.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pibasri <pibasri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/09 11:35:16 by pibasri           #+#    #+#             */
/*   Updated: 2024/06/09 12:52:05 by pibasri          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/rush.h"

void	print_unity(char *nb, char **dico, int *i)
{
	int	pos;

	if (nb[0] != '0')
	{
		if (*i)
			write(1, " ", 1);
		*i = *i + 1;
		pos = nb[0] - '0';
		write(1, dico[pos], ft_strlen(dico[pos]));
	}
}
