/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_dico.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pibasri <pibasri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/09 11:34:07 by pibasri           #+#    #+#             */
/*   Updated: 2024/06/09 13:54:44 by pibasri          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/rush.h"

static char	*add_letter(char *str, char c)
{
	int		i;
	char	*new;

	new = (char *)malloc((ft_strlen(str) + 2) * sizeof(char));
	i = 0;
	if (str)
	{
		while (str[i])
		{
			new[i] = str[i];
			i++;
		}
	}
	if (str)
		free(str);
	new[i++] = c;
	new[i] = '\0';
	return (new);
}

static char	*get_file(int fd)
{
	char	c;
	char	*file;

	c = '*';
	file = NULL;
	while (read(fd, &c, 1) > 0 && c)
		file = add_letter(file, c);
	return (file);
}

char	**get_dico(int fd)
{
	char	**dico;
	char	*file;

	file = get_file(fd);
	dico = parse_file(file);
	free(file);
	return (dico);
}

int	dict_not_found(char *num)
{
	free(num);
	write(1, "Dict Error\n", 11);
	return (1);
}

void	iterate_dict(int *i, int *j)
{
	(*j)++;
	if (*i < 20)
		(*i)++;
	else
		*i += 10;
}
