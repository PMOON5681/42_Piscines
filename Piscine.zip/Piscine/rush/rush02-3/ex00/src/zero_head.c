/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   zero_head.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pibasri <pibasri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/09 01:40:02 by pibasri           #+#    #+#             */
/*   Updated: 2024/06/09 14:01:58 by pibasri          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/rush.h"

void	zero_cutter(char *nb, char **ref)
{
	char	*res;

	while (*nb == '0' && *(nb + 1) != '\0')
		nb++;
	res = ft_strdup(nb);
	*ref = res;
	return ;
}
