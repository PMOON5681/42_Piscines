/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pibasri <pibasri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/09 11:34:17 by pibasri           #+#    #+#             */
/*   Updated: 2024/06/09 13:52:46 by pibasri          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/rush.h"

int	main(int ac, char **av)
{
	int		fd;
	char	*nb;
	char	**dico;

	if (!check_arg(ac, av, &nb))
		return (write(1, "Error\n", 6));
	if (ac == 2)
	{
		fd = open("numbers.dict", O_RDONLY);
		if (fd < 0)
			return (dict_not_found(nb));
		dico = get_dico(fd);
	}
	else
	{
		fd = open(av[1], O_RDONLY);
		if (fd < 0)
			return (dict_not_found(nb));
		dico = get_dico(fd);
	}
	if (ac == 3 && !(dico))
		return (dict_not_found(nb));
	print_nb(nb, dico);
	release(dico, 40, fd);
	return (0);
}
