/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   free_dico.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pibasri <pibasri@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/09 11:33:45 by pibasri           #+#    #+#             */
/*   Updated: 2024/06/09 13:51:05 by pibasri          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/rush.h"

void	*free_dico(char **dico, int j)
{
	while (j >= 0)
	{
		free(dico[j]);
		j--;
	}
	free(dico);
	return (NULL);
}

void	release(char **dico, int j, int fd)
{
	free_dico(dico, j);
	close(fd);
}
