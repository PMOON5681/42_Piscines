/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tjiranar <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/13 18:38:36 by tjiranar          #+#    #+#             */
/*   Updated: 2024/06/13 18:58:19 by tjiranar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strcmp(char *s1, char *s2)
{
	int	i;
	unsigned char	c1;
	unsigned char	c2;

	 i = 0;
	 while (s1[i] || s2[i])
	 {
		 c1 = (unsigned char)s1[i];
		 c2 = (unsigned char)s2[i];
		 if(s1[i] != s2[i])
			 return (c1 - c2);
		 i++;
	 }
	 return (0);
}

#include <stdio.h>
int	main(void)
{
		printf("%d\n", ft_strcmp("\201ab", "Aab"));
		return (0);
}
