/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tjiranar <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/04 20:45:24 by tjiranar          #+#    #+#             */
/*   Updated: 2024/06/14 18:04:57 by tjiranar         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	*ft_range(int min, int max)
{
	int	i;
	int	l;
	int	*n;

	l = max - min;
	n = (int *)malloc(sizeof(int) * l);
	if (!n)
		return (NULL);
	if (min >= max)
		return (NULL);
	i = 0;
	while (min < max)
	{
		n[i] = min;
		i++;
		min = min + 1;
	}
	return (n);
}

/*#include <stdio.h>

int	main(void)
{
	int	i;
	int	*n;

	n = ft_range(3,15);
	i = -1;
	while (++i < 15 - 3)
		printf("%d, ", n[i]);
	free(n);
}*/
