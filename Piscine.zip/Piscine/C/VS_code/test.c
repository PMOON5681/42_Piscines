int     ft_fibonacci(int index)
{
        int     i;

        i = 0;
        if (index == 0)
                return (0);
        if (index < 0)
                return (-1);
        return (i + ft_fibonacci(index - (i + 1)));
}

#include <stdio.h>

int     main(void)
{
        printf("%d\n", ft_fibonacci(7)); //13
}