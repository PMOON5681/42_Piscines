#!/bin/sh
find . -type f -name "*.sh" -exec basename -s .sh \;
